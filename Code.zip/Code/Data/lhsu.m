function s=lhsu(xmin,xmax,nsample,num_para)
        % function drawing Latin Hypercube draw from all parameters
    ran=rand(nsample,num_para);
    s=zeros(num_para,nsample);
    for j=1: num_para
        idx=randperm(nsample);
        P =(idx'-ran(:,j))/nsample;
        s(j,:) = xmin(j) + P.* (xmax(j)-xmin(j));
    end
