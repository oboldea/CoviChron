
close all;
load Data/pop                % load population 
pop0=pop;
load Data/hos1                % load weekly new hospitalizations, Dataset 1: by age, all risk, age categories: 0-10,10-20,,...,80-90,90+ 
load Data/hos2                % load weekly new hospitalizations, Dataset 2: medium plus high 
hos1 = hos1(2:end,:);
hos2 = hos2(2:end,:);
load Output/x_e;
x_post=x_e;
load Output/x_post_week      % load posteriors weekly new hospitalizations by age and risk
load Output/x_post_week_inf  % load posteriors weekly new hospitalizations by age and risk
% initializations
num_arisk =4;
inf = zeros(num_cat,num_ens,num_times,3); % infections, 1 high 2 med 3 low 
% x_post_week_inf = x_post_week_inf1;
% x_post_week = x_post_week_hos1;
for t=1:num_times
    for c=1:num_cat
                       inf(c,:,t,1)=sum(x_post_week_inf((c-1)*num_risk*2+(1:1:2)',:,t),1)/pop0(c,1);
                       inf(c,:,t,2)=sum(x_post_week_inf((c-1)*num_risk*2+(3:1:4)',:,t),1)/pop0(c,2);
                       inf(c,:,t,3)=sum(x_post_week_inf((c-1)*num_risk*2+(5:1:6)',:,t),1)/pop0(c,3);                  
    end
end

% plot estimates 
col1 = zeros(3,3);
col1(1,:)=rgb('Red');
col1(2,:)=rgb('Yellow');
col1(3,:)=rgb('Blue');

% calculate infections per population 
data1=readtable('dates.xlsx','ReadVariableNames',1); % import dates
date1 = datetime(data1.week, 'InputFormat', 'MM-dd-yyyy');
xtitle = ["[0-5)";"[5,10)";"[10,20)";"[20,30)";"[30,40)";"[40-50)";"[50,60)";"[60,70)";"[70,80)";"[80,90)";"90+"];
tot_inf=squeeze(sum(inf,3));
bar_inf = zeros(num_risk,num_cat,3);
ratio=zeros(num_risk,num_cat,3);
for c=1:num_cat
    for i=1:num_risk
    ratio(i,c,1)=shiftdim(mean(tot_inf(c,:,i),2));
    ratio(i,c,2)=shiftdim(quantile(tot_inf(c,:,i),0.025,2));
    ratio(i,c,3)=shiftdim(quantile(tot_inf(c,:,i),0.975,2));
    end
end
xbar = (1:1:num_risk*num_cat)';
ybar=zeros(num_cat*num_risk,3);
for j=1:3
ybar(:,j)=reshape((ratio(:,:,j)),[num_cat*num_risk 1]);
end

new_colors=repmat(col1,num_cat,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 1: plot cumulative infections by age and risk, bar charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
set(gca,'fontsize',40);
b=bar(xbar,ybar(:,1));
b.FaceColor='flat';
for j = 1:length(xbar)
    b.CData(j,:) = new_colors(j,:);
end
xticklabels({'Wild-Type','Alpha','Delta','Omicron'});set(gca,'fontsize',40);
ylabel({'Infections divided by own population'});set(gca,'Fontsize',30);

for j=1:1:length(xbar)
    aline(j)=line([xbar(j) xbar(j)],[ybar(j,2) ybar(j,3)],'Color',new_colors(j,:),'LineWidth',7);hold on;
          uistack(aline(j),'top');
end

hold off;
for j=1:1:length(xbar)
   line([xbar(j) xbar(j)],[ybar(j,2) ybar(j,3)],'Color','k','LineWidth',7);hold on;
end
name_RU={'High','Medium','Low'};
lgd=legend(aline(1:j),name_RU);
set(lgd,...
    'Position',[0.668763121021353 0.828755239195766 0.057389935994017 0.0772086095393987],...
    'FontSize',20);

hold on
sgtitle('Infections per age and risk groups 2020-2021','FontSize',40);    
lgd.FontSize = 20;  
       ax = gca;
xticks(xbar(2:3:end));
xticklabels(xtitle) 

% calculate hospitalizations per infection
inf = zeros(num_cat,num_ens,num_times,3); % infections, 1 high 2 med 3 low 
for t=1:num_times
    for c=1:num_cat
                        inf(c,:,t,1)=sum(x_post_week_inf((c-1)*num_risk*2+(1:1:2)',:,t),1);
                        inf(c,:,t,2)=sum(x_post_week_inf((c-1)*num_risk*2+(3:1:4)',:,t),1);
                        inf(c,:,t,3)=sum(x_post_week_inf((c-1)*num_risk*2+(5:1:6)',:,t),1);
    end
end
tot_inf=squeeze(sum(inf,3));

hosp = zeros(num_cat-4,num_ens,num_risk); % infections, 1 high 2 med 3 low 
for c=1:num_cat-4
    if c==1
                        hosp(c,:,1)=(sum(x_post_week((c-1)*num_risk*2+(1:1:2)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(1:1:2)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(1:1:2)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(1:1:2)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(1:1:2)',:,:),[1 3]))./sum(tot_inf(1:5,:,1),1);
                        hosp(c,:,2)=(sum(x_post_week((c-1)*num_risk*2+(3:1:4)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(3:1:4)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(3:1:4)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(3:1:4)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(3:1:4)',:,:),[1 3]))./sum(tot_inf(1:5,:,2),1);
                       hosp(c,:,3)=(sum(x_post_week((c-1)*num_risk*2+(5:1:6)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(5:1:6)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(5:1:6)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(5:1:6)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(5:1:6)',:,:),[1 3]))./sum(tot_inf(1:5,:,3),1);
    else
                        hosp(c,:,1)=sum(x_post_week((c+3)*num_risk*2+(1:1:2)',:,:),[1 3])./tot_inf(c+4,:,1);
                        hosp(c,:,2)=sum(x_post_week((c+3)*num_risk*2+(3:1:4)',:,:),[1 3])./tot_inf(c+4,:,2);
                        hosp(c,:,3)=sum(x_post_week((c+3)*num_risk*2+(5:1:6)',:,:),[1 3])./tot_inf(c+4,:,3);
   
    end
end
num_cat2=num_cat-4;
new_colors=repmat(col1,num_cat2,1);
bar_inf = zeros(num_risk,num_cat2,3);
ratio=zeros(num_risk,num_cat2,3);
for c=1:num_cat2
    for i=1:num_risk
    ratio(i,c,1)=shiftdim(mean(hosp(c,:,i),2));
    ratio(i,c,2)=shiftdim(quantile(hosp(c,:,i),0.025,2));
    ratio(i,c,3)=min(shiftdim(quantile(hosp(c,:,i),0.975,2)),1);
    end
end
% too few infections for last age category high risk, do not report 95% CrI
ratio(1,num_cat2,2) = ratio(1,num_cat2,1);
ratio(1,num_cat2,3) = ratio(1,num_cat2,1);

xbar = (1:1:num_risk*num_cat2)';
ybar=zeros(num_cat2*num_risk,3);
for j=1:3
ybar(:,j)=reshape((ratio(:,:,j)),[num_cat2*num_risk 1]);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2: plot cumulative hospitalizations/infection by age and risk, bar charts
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xtitle = ["[0-40)";"[40-50)";"[50,60)";"[60,70)";"[70,80)";"[80,90)";"90+"];
figure(2)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
set(gca,'fontsize',40);
b=bar(xbar,ybar(:,1));
b.FaceColor='flat';
for j = 1:length(xbar)
    b.CData(j,:) = new_colors(j,:);
end
ylabel({'Hospitalizations to infection ratio'});set(gca,'Fontsize',30);

for j=1:1:length(xbar)
    aline(j)=line([xbar(j) xbar(j)],[ybar(j,2) ybar(j,3)],'Color',new_colors(j,:),'LineWidth',7);hold on;
          uistack(aline(j),'top');
end

hold off;
for j=1:1:length(xbar)
   %aline(j).Color='k';
   line([xbar(j) xbar(j)],[ybar(j,2) ybar(j,3)],'Color','k','LineWidth',7);hold on;
end
name_RU={'High','Medium','Low'};
lgd=legend(aline(1:j),name_RU);
title('Hospitalizations per infections in age-risk groups 2020-2021','FontSize',30);    
lgd.FontSize = 20;  
       ax = gca;
xticks(xbar(2:3:end));
xticklabels(xtitle) 


hosp = zeros(num_cat-4,num_ens,num_risk); % infections, 1 high 2 med 3 low 
for c=1:num_cat-4
    if c==1
                        hosp(c,:,1)=(sum(x_post_week((c-1)*num_risk*2+(1:1:2)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(1:1:2)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(1:1:2)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(1:1:2)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(1:1:2)',:,:),[1 3]))/sum(pop0(1:5,1:3),"all");
                        hosp(c,:,2)=(sum(x_post_week((c-1)*num_risk*2+(3:1:4)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(3:1:4)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(3:1:4)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(3:1:4)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(3:1:4)',:,:),[1 3]))/sum(pop0(1:5,1:3),"all");
                       hosp(c,:,3)=(sum(x_post_week((c-1)*num_risk*2+(5:1:6)',:,:),[1 3])+sum(x_post_week(c*num_risk*2+(5:1:6)',:,:),[1 3])...
                            +sum(x_post_week((c+1)*num_risk*2+(5:1:6)',:,:),[1 3])+sum(x_post_week((c+2)*num_risk*2+(5:1:6)',:,:),[1 3])+...
                            sum(x_post_week((c+3)*num_risk*2+(5:1:6)',:,:),[1 3]))/sum(pop0(1:5,1:3),"all");
    else
                        hosp(c,:,1)=sum(x_post_week((c+3)*num_risk*2+(1:1:2)',:,:),[1 3])/sum(pop0(c+4,1:3),"all");
                        hosp(c,:,2)=sum(x_post_week((c+3)*num_risk*2+(3:1:4)',:,:),[1 3])/sum(pop0(c+4,1:3),"all");
                        hosp(c,:,3)=sum(x_post_week((c+3)*num_risk*2+(5:1:6)',:,:),[1 3])/sum(pop0(c+4,1:3),"all");
   
    end
end
num_cat2=num_cat-4;
new_colors=repmat(col1,num_cat2,1);
bar_inf = zeros(num_risk,num_cat2,3);
ratio=zeros(num_risk,num_cat2,3);
for c=1:num_cat2
    for i=1:num_risk
    ratio(i,c,1)=shiftdim(mean(hosp(c,:,i),2));
    ratio(i,c,2)=shiftdim(quantile(hosp(c,:,i),0.025,2));
    ratio(i,c,3)=min(shiftdim(quantile(hosp(c,:,i),0.975,2)),1);
    end
end
% too few infections for last age category high risk, do not report 95% CrI
ratio(1,num_cat2,2) = ratio(1,num_cat2,1);
ratio(1,num_cat2,3) = ratio(1,num_cat2,1);

xbar = (1:1:num_risk*num_cat2)';
ybar=zeros(num_cat2*num_risk,3);
for j=1:3
ybar(:,j)=reshape((ratio(:,:,j)),[num_cat2*num_risk 1]);
end

