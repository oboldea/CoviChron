function inference()
addpath(genpath(pwd))
close all
clear
clc;
tic;
%%%%%%%%%%%%%%%%%Inference for the SEIRHS model%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rng(2);                      % set seed 
load Data/pop                % load population 

load Data/hos1                % load weekly new hospitalizations, Dataset 1: by age, all risk, age categories: 0-10,10-20,,...,80-90,90+ 
load Data/hos2                % load weekly new hospitalizations, Dataset 2: medium plus high 
load Data/vac                 % load weekly vaccinations, data starts on Jan 18, 2021
load Data/sero1               % load sero data, 6 rounds
load Data/sero2
load Data/sero3
load Data/sero4
load Data/sero5
load Data/sero6 
load Data/cont;              % load contact survery rounds
load Data/ci

% median time sero survey in week ending in (-14 days for sero conversion)
%tsero = [datenum('23-Mar-2020');
%datenum('1-Jun-2020');datenum('14-Sep-2020');datenum('8-Feb-2021');datenum('11-Jun-2021');datenum('1-Nov-2021')];
% tsero in week number
tsero = [3;14;29;50;68;88];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SELECT SUBSAMPLE TO RUN THE MODEL PLUS INITIALIZATIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hos1 = hos1(2:end,:);
hos2 = hos2(2:end,:);

% Select subsample
bdate = datenum('27-feb-2020');  % data starts

Tstart=datenum('02-mar-2020');       % start week, week ending on March 02, 2020
Tend=datenum('27-dec-2021');         % end week, week ending on December 27,2021


% initializations

num_risk=3;                     % number of risk groups, high first, then medium, then low
num_times= 96;                   % time series sample size
num_cat=11;                      % number of age categories
num_out= 18;                    % number of state outputs of SEIRHS function for each risk-age group     
num_ens=300;                    % number of ensemble members for EAKF

pop0=pop;                       % rename pop to initial population, as pop will be used later to track pop in first and second compartment sets  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PRIORS 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% uniform priors on parameters, Latin Hypercube draw (to fix parameters, set lower bound equal to upper bound)

range   = [835 835];                    % prior range for sum of all exposed and infected on Feb 26, posterior median Rozhnova et al (2021) estimates

% model parameter prior bounds 
epsi= [0.001 0.003];   % susceptibility of 60+
fepsb    = [[0.1 0.25]; [0.25 0.75]];    % relative susceptibility 0-20, 20-60
    
nu = [ci(4:11,1) ci(4:11,2)];
f_H = repmat([1 4],4,1);
gammab = [repmat(nu(1,:),3,1);nu(2,:); nu(3:8,:);nu(8,:);f_H]; % 0-5,5-10,10-20, 20-30 same for L and H risk, else different

Zb      = [4.5 4.5];                        % incubation period, wild-type
Db      = [4.5 4.5];                      % time until recovery if not hospitalized
etaA=[1/365.5 1/365.5];                 % immunity waning from previous infection in the first set of compartments before Omicron
parabounds = [range;fepsb;epsi;gammab;Zb;Db;etaA];

deltac=[1/8;1/3;1/3];                    % median time release from hospital, calibrated
% replicate delta to be num_riskxnum_ens x num_cat x num_vax (num_vax is 2,
% number of compartment sets)
delta            = repmat([ones(2,1)*deltac(2);deltac(3);ones(8,1)*deltac(1)],1,num_ens);
% replicate it to be the same for risk groups (format:
% num_risk x num_ens x num_cat)
delta  = repmat(permute(delta,[3 2 1]),num_risk,1,1,2);


% initialize ''vaccine'' effectiveness against susceptibility and hospitalization; first column: alpha variant; second: delta
% variant; third: waning of fully vaccinated; 
ve = [[0.9;0.94] [0.8;0.94] [0;0.75]];
num_para=size(parabounds,1);


% fix regimes when contact matrices change
treg = [datenum('16-Mar-2020'); datenum('11-May-2020');datenum('16-Sep-2020');datenum('01-Dec-2020');datenum('29-Dec-2020');datenum('05-May-2021');datenum('30-Oct-2021');datenum('5-Dec-2021');datenum('31-Dec-2021')]-bdate+1;
% calculate contacts
cont_time= transf(cont,treg);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OBSERVATION ERROR VARIANCE, CALIBRATED
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

HosOEV=zeros(num_times,num_cat-1);         
for t=1:size(hos1,1)
    for c=1:num_cat-1
        HosOEV(t,c)=max(4,hos1(t,c)); % hosp Data 1
        
    end
end

num_arisk = 4; % define aggregated number of risk categories in ages 0-40, 40-60,60-80, 80+ to match merged data hos2
HosOEV2=zeros(num_times,num_arisk);  

for t=1:size(hos2,1)
    for c=1:num_arisk
        HosOEV2(t,c)=max(4,hos2(t,c)); % hosp Data 2 high and medium risk
    end
end

pop0=pop;
%draw prior
[x,pop]=initialize(pop0,num_ens,num_out,parabounds);

num_var=size(x,1);                   % number of state variables including parameters
num_s = num_var-num_para;            % number of state variables without parameters

% correct lower/upper bounds
x=checkbound_ini(x,pop0,num_cat,num_out);

% define indicator for observed hospitalizations summed across risk
% categories
H1=zeros(num_cat-1,num_out*num_risk*num_cat+num_para); 

ix_h = [[7;15];[7;15]+num_out; [7;15] + 2*num_out];
%age 0-4 and 5-10 are reported together
H1(1,ix_h)=1; H1(1,num_risk*num_out+ix_h)=1;
for i=2:num_cat-1
    % select both compartment sets and all risk categories
     H1(i,i*num_risk*num_out+ix_h)=1;
end

% calculate indexes of variables to be updated with the ETKF
upidx=[2 3 4 5 6 7 8 10 11 12 13 14 16 17];  % sussceptibles and recovered are remainders, updated with exact formulas, not with EAKF
% index within age categories
upridx = [upidx upidx+num_out upidx+2*num_out];
n_up = length(upridx); 
% index across age categories
up_idx = []; % variables in the system to be updated
for j=1:num_risk*num_cat
    up_idx = [up_idx;(j-1)*num_out+upidx];
end
up_idx = reshape(up_idx,1,size(upidx,2)*num_risk*num_cat);
nn_up = length(up_idx);

neighbor = (6:1:11)';
% calculate matrix that selects all age+risk new hospitalizations across the
% two compartment sets
uph=[7 15]; 
uph2= []; % variables in the system to be updated
for j=1:num_risk*num_cat
    uph2 = [uph2;(j-1)*num_out+uph];
end
uph2=reshape(uph2',1,num_cat*num_risk*2);
H3 = zeros(num_cat*num_risk*2,num_var);
nn_H3= size(H3,1);
for i=1:nn_H3
    H3(i,uph2(i))=1;
end
% calculate matrix that selects all age+risk new infections across the
% two compartment sets
uph=[6 14];  
uph2= []; % variables in the system to be updated
for j=1:num_risk*num_cat
    uph2 = [uph2;(j-1)*num_out+uph];
end
uph2=reshape(uph2',1,num_cat*num_risk*2);
H6 = zeros(num_cat*num_risk*2,num_var);
nn_H6= size(H6,1);
for i=1:nn_H6
    H6(i,uph2(i))=1;
end


ix2 = [1:1:4];
ix_h2 = ix2;
for c=1:num_cat-1
        ix_h2 =[ix_h2;ix_h2(end,:)+6];
end
% calculate matrix that selects  hospitalizations available in HOS2 from
% all age x risk x2 categories already weekly updated

H4 = zeros(num_arisk,nn_H3);
H4(1,reshape(ix_h2(1:5,:),20,1)) =1;
H4(2,reshape(ix_h2(6:7,:),8,1)) =1;
H4(3,reshape(ix_h2(8:9,:),8,1)) =1;
H4(4,reshape(ix_h2(10:11,:),8,1)) =1;

% calculate matrix that will help select seroprevalence for all risk groups, and
% groups age categories 80-90 and 90+ to match data availability (survey
% rounds 1 and 3)
H1_sero = zeros(num_cat-1,num_var);
for c=1:num_cat-2 % age categories below 80
H1_sero(c,(c-1)*num_risk*num_out+1:num_out:c*num_risk*num_out)=1;
end
H1_sero(num_cat-1,(num_cat-2)*num_risk*num_out+1:num_out:num_cat*num_risk*num_out)=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate matrix that will help select seroprevalence for all risk groups
% below 40 of age, and then by low and high+medium risk in the rest of age
% categories, grouping 80-90 and 90+ together to match data availability (survey
% rounds 2,4,5 6)
H2_sero = zeros(num_cat-1,num_var,num_risk);
for c=1:5 % age categories below 40 all risk categories
H2_sero(c,(c-1)*num_risk*num_out+1:num_out:c*num_risk*num_out,1)=1;
end
for c=6:num_cat-2 % age categories above forty high/medium risk
H2_sero(c,(c-1)*num_risk*num_out+1:num_out:(c-1)*num_risk*num_out+1 + (num_risk-1)*num_out,2)=1;
end
H2_sero(num_cat-1,(num_cat-2)*num_risk*num_out+1:(num_cat-2)*num_risk*num_out + (num_risk-1)*num_out,2)=1;
H2_sero(num_cat-1,(num_cat-1)*num_risk*num_out+1:(num_cat-1)*num_risk*num_out + (num_risk-1)*num_out,2)=1;
for c=6:num_cat-2 % age categories above forty low risk
H2_sero(c,(c-1)*num_risk*num_out+(num_risk-1)*num_out+1:num_out:c*num_risk*num_out,3)=1;
end
H2_sero(num_cat-1,(num_cat-2)*num_risk*num_out+(num_risk-1)*num_out+1:num_out:(num_cat-1)*num_risk*num_out,3)=1;
H2_sero(num_cat-1,(num_cat-1)*num_risk*num_out+(num_risk-1)*num_out+1:num_out:num_cat*num_risk*num_out,2)=3;
% define index that selects All, low risk and high risk from sero data
ix_sero1 = 1:1:5;
ix_sero2 = [6,8,10,12,14]; % low risk sero data index
ix_sero3 = [7,9,11,13,15]; % high risk sero data index

% initialize weekly posteriors
x_post=zeros(num_var,num_ens,num_times);                    % posterior
pop_post=zeros(num_risk,num_ens,num_cat,2,num_times);       % posterior population

x_post_hos1 = zeros(num_cat-1,num_ens,num_times);           % memorize weekly new hospitalization posteriors 1
x_post_hos2 = zeros(num_arisk,num_ens,num_times);           % memorize weekly new hospitalization posteriors 2

x_post_week = zeros(num_cat*num_risk*2,num_ens,num_times);     % memorize weekly new hospitalizations in all age x risk categories modelled
x_post_week_inf = zeros(num_cat*num_risk*2,num_ens,num_times); % memorize weekly new infections in all age x risk categories modelled

x_post_sero1 = NaN(num_cat-1,num_ens,num_times) ;             % memorize observable posterior updates for sero data 1,3 and 2,4,5,6 for first 5 ages
x_post_sero2 = NaN(num_cat-1,num_ens,num_times,2) ;           % memorize observed posterior updates for sero data 2,4,5,6 low (first 4th dim) and high risk


lam=1.10;                                                     %inflation parameter to avoid divergence 

survey1=[1;3];                                                % identify index of surveys where data is for all risk categories
survey2=[2;4;5;6];                                           % identify index of surveys where data is for high/medium and low risk categories

x_temp_check = zeros(num_risk*num_cat*2,num_ens,num_times);
for t=1:num_times
    t  % display week number 
     % variance inflate the priors to avoid filter collapse
     x=inflation(x,pop,lam,parabounds,num_cat,num_risk,num_out,num_ens,num_para); % variance inflate the right state variables
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % RUN SEIRHS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
    if t==1
        x_temp = zeros(num_var,num_ens);
    for j=1:4 % model is daily, run weekly; run for 4 days the first week, 27 Feb was a thursday. 
        VX = vac(7*(t-1)+j,:,:);
        [x,pop]=SEIRHS(x,pop,7*(t-1)+j,squeeze(cont_time(:,:,:,:,7*(t-1)+j)),num_out,ve,delta,VX,bdate,num_ens,vac,pop0);
        [x, pop] = remainder(x,pop,num_risk,num_cat,num_out,num_ens); 
         x_temp = x_temp+x; % add to extract new weekly instead of new daily hospitalizations; rest of sums are meaningless
         x_temp_check(:,:,t) = x_temp_check(:,:,t)+ H6*x;

    end
    else
        x_temp = zeros(num_var,num_ens);
    for j=1:7 % run weekly
        VX = vac(7*(t-2)+j+4,:,:);
        [x,pop]=SEIRHS(x,pop,7*(t-2)+j+4,squeeze(cont_time(:,:,:,:,7*(t-2)+j+4)),num_out,ve,delta,VX,bdate,num_ens,vac,pop0);
        [x, pop] = remainder(x,pop,num_risk,num_cat,num_out,num_ens); 
        x_temp = x_temp+x; % add to extract new weekly instead of new daily hospitalizations
        x_temp_check(:,:,t) = x_temp_check(:,:,t)+ H6*x;
    end
    end

     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate update with respect to hospitalization data HOS1 for state variables
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        x_week = H3*x_temp;    % update weekly hospitalizations in all age and risk categories for both compartments
        x_week_inf = H6*x_temp;
        for c=1:num_cat-1
                    hos_cnt=H1(c,:)*x_temp; % extract new weekly hospital admission prior after inflation
                    hos_var = HosOEV(t,c);
                    hos_prior_var = var(hos_cnt(1,:));
                    hos_post_var = hos_prior_var*hos_var/(hos_prior_var+hos_var);
                    if hos_prior_var==0  % if degenerate, increase variance 
                        hos_post_var=1e-3;
                        hos_prior_var=1e-3;
                    end
                    hos_prior_mean = mean(hos_cnt(1,:),2);
                    hos_post_mean = hos_post_var*(hos_prior_mean/hos_prior_var + hos1(t,c)/hos_var);
                    hos_alpha = (hos_var/(hos_var+hos_prior_var)).^0.5;
                    x_post_hos1(c,:,t) = hos_post_mean + hos_alpha*(hos_cnt(1,:)-hos_prior_mean);
                    dy1 = hos_post_mean + hos_alpha*(hos_cnt(1,:)-hos_prior_mean)-hos_cnt(1,:); %change in posterior from prior for observed variable

                    rr1= zeros(1,num_var);
                    rr1_week = zeros(1,num_risk*num_cat*2);
                    rr1_week_inf = zeros(1,num_risk*num_cat*2);
                   
     
                    for kk=1:n_up % covariance of neighboring unobserved variables
                    j=upridx(kk);
                    A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                    rr1((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    A=cov(x(c*num_out*num_risk+j,:),hos_cnt);
                    rr1(c*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    end
          
                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr1(j)=A(2,1)/hos_prior_var;  
                    end
       
                    % update weekly hospitalizations in own age/risk categories
                    if c==1
                    for j=1:4*num_risk
                            A=cov(x_week(j,:),hos_cnt);   
                            rr1_week(j)=A(2,1)/hos_prior_var;  %covariance of  all weekly hosp  with observed  data
                    end
                    else
                    for j=1:2*num_risk
                            A=cov(x_week(2*num_risk*c+j,:),hos_cnt);   
                            rr1_week(2*num_risk*c+j)=A(2,1)/hos_prior_var;  %covariance of  all weekly hosp  with observed  data
                    end
                    end
                    % update weekly infections in own age/risk categories
                
                    if c==1
                    for j=1:4*num_risk
                            A=cov(x_week_inf(j,:),hos_cnt);   
                            rr1_week_inf(j)=A(2,1)/hos_prior_var;  %covariance of  all weekly inf  with observed  data
                    end
                    else
                    for j=1:2*num_risk
                            A=cov(x_week(2*num_risk*c+j,:),hos_cnt);   
                            rr1_week_inf(2*num_risk*c+j)=A(2,1)/hos_prior_var;  %covariance of  all weekly inf  with observed  data
                    end
                    end

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Posterior updates with respect to hospitalization data for all state variables and parameters
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            dx=rr1'*dy1;
            % update daily variables
            x=x+dx;
   
            % update weekly variables
            dx_week = rr1_week'*dy1; 
            dx_week_inf = rr1_week_inf'*dy1;
            x_week = x_week+dx_week;
            x_week_inf = x_week_inf+dx_week_inf;
            % check they did not migrate to unreasonable values
            x = checkbound(x,pop,parabounds,num_cat,num_out);
            [x_week, x_post_hos1(:,:,t)]= checkbound_week(x_week,x_post_hos1(:,:,t));
            x_week_inf= checkbound_week(x_week_inf,x_post_hos1(:,:,t));
        
            end     % stop loop over age categories 
            x_post_week(:,:,t) =x_week;
            x_post_week_inf(:,:,t)=x_week_inf;
     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate update with respect to hospitalization data HOS2 for state variables
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             
 for c=1:num_arisk
         hos_cnt=H4(c,:)*x_post_week(:,:,t); % new weekly hospital admissions, select groups available
         if hos2(t,c)>0 % if data is available, update
                     hos_var = HosOEV2(t,c);
                     hos_prior_var = var(hos_cnt(1,:));
                      hos_post_var = hos_prior_var*hos_var/(hos_prior_var+hos_var);
                    if hos_prior_var==0  % if degenerate, increase variance 
                        hos_post_var=1e-3;
                        hos_prior_var=1e-3;
                    end
                    hos_prior_mean = mean(hos_cnt(1,:),2);
                    hos_post_mean = hos_post_var*(hos_prior_mean/hos_prior_var + hos2(t,c)/hos_var);
                    hos_alpha = (hos_var/(hos_var+hos_prior_var)).^0.5;
                    x_post_hos2(c,:,t) = hos_post_mean + hos_alpha*(hos_cnt(1,:)-hos_prior_mean);
                    dy2 = hos_post_mean + hos_alpha*(hos_cnt(1,:)-hos_prior_mean)-hos_cnt(1,:); %change in posterior from prior for observed variable

                    rr2= zeros(1,num_var);
                    rr2_week = zeros(1,num_risk*num_cat*2);
                    rr2_week_inf = zeros(1,num_risk*num_cat*2);

                    if c==1
                    for cc=1:5 % update only for ages for which data is available
                    for kk=1:n_up
                    j=upridx(kk);
                    A=cov(x((cc-1)*num_out*num_risk+j,:),hos_cnt);
                    rr2((cc-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    end
                    end
                    elseif c==2
                    for cc=6:7 
                    for kk=1:n_up
                    j=upridx(kk);
                    A=cov(x((cc-1)*num_out*num_risk+j,:),hos_cnt);
                    rr2((cc-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    end
                    end
                    elseif c==3
                    for cc=8:9 % update only risk categories for which the data pertains to
                    for kk=1:n_up
                    j=upridx(kk);
                    A=cov(x((cc-1)*num_out*num_risk+j,:),hos_cnt);
                    rr2((cc-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    end
                    end
                    else
                    for cc=10:11 % update only risk categories for which the data pertains to
                    for kk=1:n_up
                    j=upridx(kk);
                    A=cov(x((cc-1)*num_out*num_risk+j,:),hos_cnt);
                    rr2((cc-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                    end
                    end
                    end

                    %update  all parameters 
                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr2(j)=A(2,1)/hos_prior_var;  
                    end

                    % update weekly hospitalizations in all age/risk categories
                    for j=1:num_risk*num_cat*2
                            A=cov(x_post_week(j,:,t),hos_cnt);   
                            rr2_week(j)=A(2,1)/hos_prior_var;  
                    end 
                     % update weekly infections in all age/risk categories
                    for j=1:num_risk*num_cat*2
                            A=cov(x_post_week_inf(j,:,t),hos_cnt);   
                            rr2_week_inf(j)=A(2,1)/hos_prior_var;  
                    end 

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Posterior updates with respect to hospitalization data for all state variables and parameters
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            dx=rr2'*dy2;
            x=x+dx;
            % update weekly variables
            dx_week = rr2_week'*dy2;
            x_post_week(:,:,t) =x_post_week(:,:,t)+dx_week;
            dx_week_inf = rr2_week_inf'*dy2;
            x_post_week_inf(:,:,t) =x_post_week_inf(:,:,t)+dx_week_inf;
            x = checkbound(x,pop,parabounds,num_cat,num_out);
            [x_post_week(:,:,t), x_post_hos2(:,:,t)]= checkbound_week(x_post_week(:,:,t),x_post_hos2(:,:,t));
            x_post_week_inf(:,:,t)= checkbound_week(x_post_week_inf(:,:,t),x_post_hos2(:,:,t)); 
  
         end   
 end     % stop loop over risk categories 
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % Calculate updates with respect to sero data rounds 1 and 3
            % (only all risk categories available in the data)
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                
for c=1:num_cat-1
       for se=1:length(survey1)
              if se==1
                  data_sero = sero1; 
              else
                  data_sero = sero3;
              end
                        if t==tsero(survey1(se))
                            N_sero    = data_sero.sample(c);    % multiply with sample size for better updates
                            % retrieve distribution of seroprevalence
                            locidx=1:num_out:num_risk*num_out;
                            if c<num_cat-1
                            sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:),1)/sum(pop0(c,:),2))*N_sero;
                            else
                            aa1 = sum(x((c-1)*num_out*num_risk+locidx,:),1) + sum(x(c*num_out*num_risk+locidx,:),1);
                            aa2 = sum(pop0(c,:)+pop0(c+1,:),2);
                            sero_cnt=(1-aa1/aa2)*N_sero;  
                            end
                            sero_var = (data_sero.variance(c)/10000).*(N_sero^2);
                            prior_mean = mean(sero_cnt(1,:));
                            prior_var = var(sero_cnt(1,:));
                            obs_mean = (data_sero.mean(c)/100)*N_sero;
                            post_var = prior_var*sero_var/(prior_var+sero_var);
                            if prior_var==0%if degenerate
                                post_var=1e-3;
                                prior_var=1e-3;
                            end
                            post_mean = post_var*(prior_mean/prior_var +obs_mean/sero_var); 
                            alpha = (sero_var/(sero_var+prior_var)).^0.5;
                            x_post_sero1(c,:,t)=(post_mean + alpha*(sero_cnt-prior_mean))/N_sero;
                            dy3 = post_mean + alpha*(sero_cnt-prior_mean)-sero_cnt;  % difference posterior and prior for observed sero variable
                            rr3= zeros(1,num_var);
                            rr3_week = zeros(1,num_risk*num_cat*2);
                            rr3_week_inf = zeros(1,num_risk*num_cat*2);
                           

                        % update only for ages for which data is available
                        if c<num_cat
                            for kk=1:n_up
                            j=upridx(kk);
                            A=cov(x((c-1)*num_out*num_risk+j,:),sero_cnt);
                            rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                            end
                        else
                            for kk=1:n_up
                            j=upridx(kk);
                            A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                            rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                            A=cov(x(c*num_out*num_risk+j,:),hos_cnt);
                            rr3(c*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                            end
                        end
                        % update weekly hospitalizations in all age/risk categories
                        for j=1:num_risk*num_cat*2
                            A=cov(x_post_week(j,:,t),sero_cnt);   
                            rr3_week(j)=A(2,1)/hos_prior_var;  
                        end 
                        % update weekly infections in all age/risk categories
                        for j=1:num_risk*num_cat*2
                            A=cov(x_post_week_inf(j,:,t),sero_cnt);   
                            rr3_week_inf(j)=A(2,1)/hos_prior_var;  
                        end 

                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr3(j)=A(2,1)/hos_prior_var;  
                    end
              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                Posterior updates with respect to sero data for all state variables and parameters
              %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        dx=rr3'*dy3;
                        x=x+dx;
                            % update weekly variables
                            dx_week = rr3_week'*dy3;
                            x_post_week(:,:,t) =x_post_week(:,:,t)+dx_week;
                             dx_week_inf = rr3_week_inf'*dy3;
                             x_post_week_inf(:,:,t) =x_post_week_inf(:,:,t)+dx_week_inf;
                            % check that posteriors did not migrate out of the prior bound
                            x = checkbound(x,pop,parabounds,num_cat,num_out);
                            [x_post_week(:,:,t), x_post_hos2(:,:,t)]= checkbound_week(x_post_week(:,:,t),x_post_hos2(:,:,t));
                            x_post_week_inf(:,:,t)= checkbound_week(x_post_week_inf(:,:,t),x_post_hos2(:,:,t)); 
  
                    end
              end
end
% 
%          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%             % Calculate updates with respect to sero data rounds 2 and 4-6
%             % (all, low and high risk categories available in the data)
%             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
for c=1:num_cat-1
              for se=1:length(survey2)
              if se==1
                  data_sero = sero2; 
              elseif se==2
                  data_sero = sero4;
              elseif se==3
                  data_sero = sero5;
              elseif se==4
                  data_sero = sero6;
              end
              if c<=5
                        if t==tsero(survey2(se))
                        N_sero    = data_sero.sample(c);    % multiply with sample size for better updates
                        % retrieve distribution of seroprevalence
                        locidx=1:num_out:num_risk*num_out;
                        sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:),1)/sum(pop0(c,:),2))*N_sero;
                        sero_var = (data_sero.variance(c)/10000).*(N_sero^2);
                        prior_mean = mean(sero_cnt(1,:));
                        prior_var = var(sero_cnt(1,:));
                        obs_mean = (data_sero.mean(c)/100)*N_sero;
                        post_var = prior_var*sero_var/(prior_var+sero_var);
                        if prior_var==0%if degenerate
                            post_var=1e-3;
                            prior_var=1e-3;
                        end
                        post_mean = post_var*(prior_mean/prior_var +obs_mean/sero_var); 
                                alpha = (sero_var/(sero_var+prior_var)).^0.5;
                        x_post_sero1(c,:,t)=(post_mean + alpha*(sero_cnt-prior_mean))/N_sero;
                        dy3 = post_mean + alpha*(sero_cnt-prior_mean)-sero_cnt;  % difference posterior and prior for observed sero variable
                        rr3= zeros(1,num_var);
                        rr3_week = zeros(1,num_risk*num_cat*2);
                        rr3_week_inf = zeros(1,num_risk*num_cat*2);

                     % update neighbors
                        if c<num_cat
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                        rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        end
                        else
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                        rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        A=cov(x(c*num_out*num_risk+j,:),hos_cnt);
                        rr3(c*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        end
                        end
                        % update weekly hospitalizations in all age/risk categories
                            for j=1:num_risk*num_cat*2
                                A=cov(x_post_week(j,:,t),sero_cnt);   
                            	rr3_week(j)=A(2,1)/hos_prior_var;  
                            end
                                                    % update weekly infections in all age/risk categories
                        for j=1:num_risk*num_cat*2
                            A=cov(x_post_week_inf(j,:,t),sero_cnt);   
                            rr3_week_inf(j)=A(2,1)/hos_prior_var;  
                        end 
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % Posterior updates with respect to sero data for all state variables and parameters
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr3(j)=A(2,1)/hos_prior_var;  %covariance of  all variables in the system and parameters with observed sero data
                    end
                         dx=rr3'*dy3;
                         x=x+dx;
                         % update weekly variables
                         dx_week = rr3_week'*dy3;
                         x_post_week(:,:,t) =x_post_week(:,:,t)+dx_week;
                         dx_week_inf = rr3_week_inf'*dy3;
                         x_post_week_inf(:,:,t) =x_post_week_inf(:,:,t)+dx_week_inf;
                      end
              else
                        if t==tsero(survey2(se))
                        locidx=(num_risk-1)*num_out+1:num_out:num_risk*num_out;
                            if c<num_cat-1
                            N_sero    = data_sero.sample(ix_sero2(c-4));    
                            % retrieve distribution of seroprevalence
                            sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:),1)/pop0(c,3))*N_sero;
                            sero_var = (data_sero.variance(ix_sero2(c-4))/10000).*(N_sero^2);
                            obs_mean = (data_sero.mean(ix_sero2(c-4))/100)*N_sero;
                            else
                            N_sero    = data_sero.sample(ix_sero2(end));   
                            % retrieve distribution of seroprevalence
                            sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:)+x(c*num_out*num_risk+locidx,:),1)/(pop0(c,3)+pop0(c+1,3)))*N_sero;
                            sero_var = (data_sero.variance(ix_sero2(end))/10000).*(N_sero^2);
                            obs_mean = (data_sero.mean(ix_sero2(end))/100)*N_sero;
                            end
                        prior_mean = mean(sero_cnt(1,:));
                        prior_var = var(sero_cnt(1,:));
                        post_var = prior_var*sero_var/(prior_var+sero_var);
                        if prior_var==0%if degenerate
                            post_var=1e-3;
                            prior_var=1e-3;
                        end
                        post_mean = post_var*(prior_mean/prior_var +obs_mean/sero_var); 
                        alpha = (sero_var/(sero_var+prior_var)).^0.5;
                        x_post_sero2(c,:,t,1)=(post_mean + alpha*(sero_cnt-prior_mean))/N_sero;
                        dy3 = post_mean + alpha*(sero_cnt-prior_mean)-sero_cnt;  % difference posterior and prior for observed sero variable
                        rr3= zeros(1,num_var);
                        rr3_week = zeros(1,num_risk*num_cat*2);
                        rr3_week_inf = zeros(1,num_risk*num_cat*2);
                              % update neighbors
                        if c<num_cat-1
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out+j,:),hos_cnt);
                        rr3((c-1)*num_out+j)=A(2,1)/hos_prior_var;
                        end
                        else
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                        rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        A=cov(x(c*num_out*num_risk+j,:),hos_cnt);
                        rr3(c*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        end
                        end

                        % update weekly hospitalizations in all age/risk categories
                        for j=1:num_risk*num_cat*2
                        A=cov(x_post_week(j,:,t),sero_cnt);   
                        rr3_week(j)=A(2,1)/hos_prior_var; 
                        end 
                        % update weekly infections in all age/risk categories
                        for j=1:num_risk*num_cat*2
                            A=cov(x_post_week_inf(j,:,t),sero_cnt);   
                            rr3_week_inf(j)=A(2,1)/hos_prior_var;  
                        end 
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % Posterior updates with respect to sero data for all state variables and parameters
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        
                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr3(j)=A(2,1)/hos_prior_var;  %covariance of  all variables in the system and parameters with observed sero data
                    end
                        dx=rr3'*dy3;
                         x=x+dx;
                         % update weekly variables
                         dx_week = rr3_week'*dy3;
                         x_post_week(:,:,t) =x_post_week(:,:,t)+dx_week;
                         dx_week_inf = rr3_week_inf'*dy3;
                         x_post_week_inf(:,:,t) =x_post_week_inf(:,:,t)+dx_week_inf;

                     % update with high/medium risk group data

                        % retrieve distribution of seroprevalence
                        locidx=1:num_out:(num_risk-1)*num_out;
                        if c<num_cat-1
                        N_sero    = data_sero.sample(ix_sero3(c-4));    % select high/medium risk data
                        sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:),1)/sum(pop0(c,1:2),2))*N_sero;
                        sero_var = (data_sero.variance(ix_sero3(c-4))/10000).*(N_sero^2);
                        prior_mean = mean(sero_cnt(1,:));
                        prior_var = var(sero_cnt(1,:));
                        obs_mean = (data_sero.mean(ix_sero3(c-4))/100)*N_sero;
                        else
                         N_sero    = data_sero.sample(ix_sero3(end));   % select high/medium risk data
                        % retrieve distribution of seroprevalence
                        sero_cnt=(1-sum(x((c-1)*num_out*num_risk+locidx,:)+x(c*num_out*num_risk+locidx,:),1)/(sum(pop0(c:c+1,1:2),[1,2])))*N_sero;
                        sero_var = (data_sero.variance(ix_sero3(end))/10000).*(N_sero^2);
                        obs_mean = (data_sero.mean(ix_sero3(end))/100)*N_sero;
                        end
                        post_var = prior_var*sero_var/(prior_var+sero_var);
                        if prior_var==0%if degenerate
                            post_var=1e-3;
                            prior_var=1e-3;
                        end
                        post_mean = post_var*(prior_mean/prior_var +obs_mean/sero_var); 
                        alpha = (sero_var/(sero_var+prior_var)).^0.5;
                        x_post_sero2(c,:,t,2)=(post_mean + alpha*(sero_cnt-prior_mean))/N_sero;
                        dy3 = post_mean + alpha*(sero_cnt-prior_mean)-sero_cnt;  % difference posterior and prior for observed sero variable
                        rr3= zeros(1,num_var);
                        rr3_week = zeros(1,num_risk*num_cat*2);
                        rr3_week_inf = zeros(1,num_risk*num_cat*2);

                        if c<num_cat-1
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                        rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        end
                        else
                        for kk=1:n_up
                        j=upridx(kk);
                        A=cov(x((c-1)*num_out*num_risk+j,:),hos_cnt);
                        rr3((c-1)*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        A=cov(x(c*num_out*num_risk+j,:),hos_cnt);
                        rr3(c*num_out*num_risk+j)=A(2,1)/hos_prior_var;
                        end
                        end

                        % update weekly hospitalizations in all age/risk categories
                        for j=1:num_risk*num_cat*2
                        A=cov(x_post_week(j,:,t),sero_cnt);   
                        rr3_week(j)=A(2,1)/hos_prior_var;  
                        end 
                        % update weekly infections in all age/risk categories
                        for j=1:num_risk*num_cat*2
                            A=cov(x_post_week_inf(j,:,t),sero_cnt);   
                            rr3_week_inf(j)=A(2,1)/hos_prior_var; 
                        end 
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                        % Posterior updates with respect to sero data for all state variables and parameters
                        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                         
                    for j=num_var-num_para+1:num_var
                            A=cov(x(j,:),hos_cnt);   
                            rr3(j)=A(2,1)/hos_prior_var; 
                    end
                        dx=rr3'*dy3;
                         x=x+dx;
                         % update weekly variables
                         dx_week = rr3_week'*dy3;
                         x_post_week(:,:,t) =x_post_week(:,:,t)+dx_week;
                         dx_week_inf = rr3_week_inf'*dy3;
                         x_post_week_inf(:,:,t) =x_post_week_inf(:,:,t)+dx_week_inf;
                        end
               end
           end
           

          end

    [x_post_week(:,:,t), x_post_hos2(:,:,t)]= checkbound_week(x_post_week(:,:,t),x_post_hos2(:,:,t)); 
    x_post_week_inf(:,:,t)= checkbound_week(x_post_week_inf(:,:,t),x_post_hos2(:,:,t)); 
    x=checkbound(x,pop,parabounds,num_cat,num_out); %check again to ensure no negative state variables at the end of the sample

    [x, pop] = remainder(x,pop,num_risk,num_cat,num_out,num_ens);  % update susceptibles and recovered in the first comp. set (S, R) and in the second compartment set (SV, RV); update population in these
    % compartment sets

  x = checkbound(x,pop,parabounds,num_cat,num_out);
   % memorize posteriors at each time point
  x_post(:,:,t)=x;
  pop_post(:,:,:,:,t)=pop; % memorize movement of population from compartment set 1 to compartment set 2

end
    
% calculate posteriors aggregated into various age/risk categories for
% plotting
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% update with respect to first hospitalization data
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hos_fit = x_post_hos1; % updates of observable quantities
% select from x_post_week the variables that were updated and aggregate
% according to data hos1 availability, and check their sum matches the
% x_post_hos1
H5 = zeros(num_cat-1,num_cat*num_risk*2);
H5(1,1:4*num_risk)=1; % ages 0-4 and 5-10 are reported together
for c=2:num_cat-1
H5(c,4*num_risk+2*num_risk*(c-2)+1:4*num_risk+2*num_risk*(c-1))=1;
end
hos_fit_sum = zeros(num_cat-1,num_ens,num_times);
for t=1:num_times
hos_fit_sum(:,:,t) = H5*x_post_week(:,:,t);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% update with respect to second hospitalization data, for high/medium risk
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
hos2_fit= x_post_hos2; % updates of observable quantities
% check if sum of unobserved updates match that of observed ones
hos2_fit_sum= zeros(num_arisk,num_ens,num_times);
for t=1:num_times
hos2_fit_sum(:,:,t) = H4*x_post_week(:,:,t);
end
% calculate low risk by age
hos_fit_low = zeros(num_arisk,num_ens,num_times);
hos_fit_low(1,:,:) = sum(hos_fit_sum(1:4,:,:),1) - hos2_fit_sum(1,:,:);
hos_fit_low(2,:,:) = sum(hos_fit_sum(5:6,:,:),1) - hos2_fit_sum(2,:,:);
hos_fit_low(3,:,:) = sum(hos_fit_sum(7:8,:,:),1) - hos2_fit_sum(3,:,:);
hos_fit_low(4,:,:) = sum(hos_fit_sum(9:10,:,:),1)- hos2_fit_sum(4,:,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% update with respect to sero data all risk groups
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sero_fit = x_post_sero1; % observable updates
sero_fit_sum = zeros(num_cat-1,num_ens,num_times); % unobservable updates
locidx=1:num_out:num_risk*num_out;
for t=1:num_times
    for c=1:num_cat-1
                    if c<num_cat-1
                        sero_fit_sum(c,:,t)=max(1-sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1)/sum(pop0(c,:),2),0);
                        else
                            aa1 = sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1) + sum(x_post(c*num_out*num_risk+locidx,:,t),1);
                            aa2 = sum(pop0(c,:)+pop0(c+1,:),2);
                        sero_fit_sum(c,:,t)=max((1-aa1/aa2),0);  
                    end
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% update with respect to sero data - surveys with separate risk groups 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sero_fit2 = x_post_sero2; % observable updates
sero_fit_sum2 = zeros(num_cat-1,num_ens,num_times,2); % unobservable updates
for t=1:num_times
    for c=1:num_cat-1
                    if c<num_cat-1
                        locidx=(num_risk-1)*num_out+1:num_out:num_risk*num_out;
                        sero_fit_sum2(c,:,t,1)=max(1-sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1)/pop0(c,3),0);
                        locidx=1:num_out:(num_risk-1)*num_out;
                        sero_fit_sum2(c,:,t,2)=max(1-sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1)/sum(pop0(c,1:2),2),0);
                    else
                        locidx=(num_risk-1)*num_out+1:num_out:num_risk*num_out;
                            aa1 = sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1) + sum(x_post(c*num_out*num_risk+locidx,:,t),1);
                            aa2 = pop0(c,3);
                        sero_fit_sum2(c,:,t,1)=max(1-aa1/aa2,0);  
                        locidx=1:num_out:(num_risk-1)*num_out;
                            aa1 = sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1) + sum(x_post(c*num_out*num_risk+locidx,:,t),1);
                            aa2 = sum(pop0(c:c+1,1:2),"all");
                         sero_fit_sum2(c,:,t,2)=max(1-aa1/aa2,0);  
                    end
    end
end
% check only second set of compartments susceptibles
% ix_n = 6-num_out/2;
% sero_fit_sum3 = zeros(num_cat-1,num_ens,num_times,2); % unobservable updates
% for t=1:num_times
%     for c=1:num_cat-1
%                     if c<num_cat-1
%                         locidx=(num_risk-1)*num_out+num_out/2+ix_n:num_out:num_risk*num_out;
%                         sero_fit_sum3(c,:,t,1)=max(sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1)/pop0(c,3),0);
%                         locidx=num_out/2+ix_n:num_out:(num_risk-1)*num_out;
%                         sero_fit_sum3(c,:,t,2)=max(sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1)/sum(pop0(c,1:2),2),0);
%                     else
%                          locidx=(num_risk-1)*num_out+num_out/2+ix_n:num_out:num_risk*num_out;
%                             aa1 = sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1) + sum(x_post(c*num_out*num_risk+locidx,:,t),1);
%                             aa2 = pop0(c,3);
%                         sero_fit_sum3(c,:,t,1)=max(aa1/aa2,0);  
%                         locidx=num_out/2+ix_n:num_out:(num_risk-1)*num_out;
%                             aa1 = sum(x_post((c-1)*num_out*num_risk+locidx,:,t),1) + sum(x_post(c*num_out*num_risk+locidx,:,t),1);
%                             aa2 = sum(pop0(c:c+1,1:2),"all");
%                          sero_fit_sum3(c,:,t,2)=max(aa1/aa2,0);  
%                     end
%     end
% end
toc
x_e=x_post;
save("Output/x_e.mat","x_e");
save("Output/pop_post.mat","pop_post");
save("Output/parabounds.mat","parabounds");
save("Output/hos_fit.mat","hos_fit");
save("Output/hos_fit_sum.mat","hos_fit_sum");
save("Output/hos2_fit.mat","hos2_fit");
save("Output/hos2_fit_sum.mat","hos2_fit_sum");
save("Output/hos_fit_low.mat","hos_fit_low");
save("Output/sero_fit.mat","sero_fit");
save("Output/sero_fit_sum.mat","sero_fit_sum");
save("Output/sero_fit2.mat","sero_fit2");
save("Output/sero_fit_sum2.mat","sero_fit_sum2");
save("Output/x_post_week.mat","x_post_week");
save("Output/x_post_week_inf.mat","x_post_week_inf");