% function transf.m
%  calculate the contacts in each regime


% INPUTS
% cont              : num_survey x num_cat x num_risk x num_cat x num_risk  data: load total contacts
%                     survey rounds
% treg              : num_reg x 1 calibrated end points of each regime
% OUTPUT
% cont_time         : num_cat x num_risk x num_cat x num_risk x num_times
% contacs over time

function cont_time = transf(cont,treg)

num_cat     = size(cont,2);
num_risk    = size(cont,3);
num_times   = treg(end);
cont_time  = zeros(num_cat,num_risk,num_cat,num_risk,num_times);
cont_time(:,:,:,:,1:treg(1)) = repmat(squeeze(cont(1,:,:,:,:)),1,1,1,1,treg(1));
cont_time(:,:,:,:,treg(1)+1:treg(2)) = repmat(squeeze(cont(2,:,:,:,:)),1,1,1,1,treg(2)-treg(1));
cont_time(:,:,:,:,treg(2)+1:treg(3)) = repmat(squeeze(cont(3,:,:,:,:)),1,1,1,1,treg(3)-treg(2));
cont_time(:,:,:,:,treg(3)+1:treg(4)) = repmat(squeeze(cont(4,:,:,:,:)),1,1,1,1,treg(4)-treg(3));
cont_time(:,:,:,:,treg(4)+1:treg(5)) = repmat(squeeze(cont(2,:,:,:,:)),1,1,1,1,treg(5)-treg(4)); %lockdown contacts
cont_time(:,:,:,:,treg(5)+1:treg(6)) = max(repmat(squeeze(cont(5,:,:,:,:)),1,1,1,1,treg(6)-treg(5)),cont_time(:,:,:,:,treg(5)));
cont_time(:,:,:,:,treg(6)+1:treg(7)) = repmat(squeeze(cont(6,:,:,:,:)),1,1,1,1,treg(7)-treg(6));
cont_time(:,:,:,:,treg(6)+1:treg(7)) = repmat(squeeze(cont(4,:,:,:,:)),1,1,1,1,treg(7)-treg(6));
cont_time(:,:,:,:,treg(7)+1:treg(8)) = repmat(squeeze(cont(7,:,:,:,:)),1,1,1,1,treg(8)-treg(7));
cont_time(:,:,:,:,treg(8)+1:treg(9)) = repmat(squeeze(cont(2,:,:,:,:)),1,1,1,1,treg(9)-treg(8)); %lockdown contacts

