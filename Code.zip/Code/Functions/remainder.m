function [x, pop] = remainder(x,pop,num_risk,num_cat,num_out,num_ens)
 % update susceptibles and recovered in the first comp. set (S, R) and in the second compartment set (SV, RV); update population in these
    % compartment sets
for i=1:num_risk
        for c=1:num_cat
            Waned=x((c-1)*num_out*num_risk+(i-1)*num_out+16,:);  
            pop(i,:,c,1)=pop(i,:,c,1)-Waned; % newly waned and unvax move to pop. in the second compartment set
            pop(i,:,c,2)=pop(i,:,c,2)+Waned;
            WunV=x((c-1)*num_out*num_risk+(i-1)*num_out+18,:); % retrieve newly waned and unvax, and add them to total waned and unvax so they may be vaccinated later
            WunV=WunV+Waned;                 
            x((c-1)*num_out*num_risk+(i-1)*num_out+18,:)=WunV; % updated the total unwaned and vax
            R=x((c-1)*num_out*num_risk+(i-1)*num_out+5,:);    
            Rnew=x((c-1)*num_out*num_risk+(i-1)*num_out+8,:);
            R=R+Rnew-Waned;                                   % update R in the first compartment set
            RV=x((c-1)*num_out*num_risk+(i-1)*num_out+13,:);    
            RVnew=x((c-1)*num_out*num_risk+(i-1)*num_out+17,:);
            RV=RVnew+RV;                                      % update R in the second compartment set
            % update susceptibles in the two compartment set
            S=pop(i,:,c,1)-x((c-1)*num_out*num_risk+(i-1)*num_out+2,:)-x((c-1)*num_out*num_risk+(i-1)*num_out+3,:)-x((c-1)*num_out*num_risk+(i-1)*num_out+4,:)-R;
            SV=pop(i,:,c,2)-x((c-1)*num_out*num_risk+(i-1)*num_out+10,:)-x((c-1)*num_out*num_risk+(i-1)*num_out+11,:)-x((c-1)*num_out*num_risk+(i-1)*num_out+12,:)-RV;

           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           % Check that susceptibles or recovered are not negative due to
           % population depletion of the first compartment set in some regions 
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       % 
            if any(S<0,'all')
                for jjj=1:num_ens
                    if S(jjj)<0
                        S(jjj)=0;
                        R(jjj)=pop(i,jjj,c,1)-x(num_out*num_risk*(c-1)+(i-1)*num_out+4,jjj)-x(num_out*num_risk*(c-1)+(i-1)*num_out+3,jjj)-x(num_out*num_risk*(c-1)+(i-1)*num_out+2,jjj);
                    end
                end
            end
            if any(SV<0,'all')
                for jjj=1:num_ens
                    if SV(jjj)<0
                        SV(jjj)=0;
                        RV(jjj)=pop(i,jjj,c,2)-x(num_out*num_risk*(c-1)+(i-1)*num_out+12,jjj)-x(num_out*num_risk*(c-1)+(i-1)*num_out+11,jjj)-x(num_out*num_risk*(c-1)+(i-1)*num_out+10,jjj);
                    end
                end
            end
            if any(R<0,'all')
                for jjj=1:num_ens
                    if R(jjj)<0
                        R(jjj)=0;
                        tem=pop(i,jjj,c,1);
                        pop(i,jjj,c,1)=x(num_out*num_risk*(c-1)+(i-1)*num_out+4,jjj)+x(num_out*num_risk*(c-1)+(i-1)*num_out+3,jjj)+x(num_out*num_risk*(c-1)+(i-1)*num_out+2,jjj)+x(num_out*num_risk*(c-1)+(i-1)*num_out+1,jjj);
                        RV(jjj)=RV(jjj)+tem-pop(i,jjj,c,1);
                        pop(i,jjj,c,2)=pop(i,jjj,c,2)+tem-pop(i,jjj,c,1);
                    end
                end
            end
            if any(RV<0,'all')
                for jjj=1:num_ens
                    if RV(jjj)<0
                        RV(jjj)=0;
                        pop(i,jjj,c,2)=x(num_out*num_risk*(c-1)+(i-1)*num_out+12,jjj)+x(num_out*num_risk*(c-1)+(i-1)*num_out+11,jjj)+x(num_out*num_risk*(c-1)+(i-1)*num_out+10,jjj)++x(num_out*num_risk*(c-1)+(i-1)*num_out+9,jjj);
                    end
                end
            end
            x((c-1)*num_out*num_risk+(i-1)*num_out+1,:)=S;
            x((c-1)*num_out*num_risk+(i-1)*num_out+9,:)=SV;
            x((c-1)*num_out*num_risk+(i-1)*num_out+5,:)=R;
            x((c-1)*num_out*num_risk+(i-1)*num_out+13,:)=RV;
        % 
        end
end
