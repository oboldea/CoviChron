% function checkbound.m
% checks if values of variables are reasonable: do not exceed population, are non-negative
% redistributes parameters into their prior bounds if they are out of bound
% checks if initial priors lead to unreasonable values of S
% INPUTS
% x             : (num_out x num_risk x num_cat +num_para) x num_ens prior draws of state
%                  variables and parameters
% pop                 : num_risk x num_ens x num_cat x2, population in each
%                       region /age category for the 2 sets of compartments: naive and vaccinated
%                       or previously infected
% parabounds    : num_para x 2 prior parameter bounds
% num_cat       : scalar, no. of age categories
% num_out       : scalar, number of state variable per age x risk that
%                 are updated
% OUTPUT
% x             : (num_out x num_risk x num_cat +num_para) x num_ens bound corrected prior draws of state
%                  variables and parameters

function x = checkbound(x,pop,parabounds,num_cat,num_out)

xmin=parabounds(:,1);
xmax=parabounds(:,2);
num_para=size(parabounds,1);
num_risk=size(pop,1);
num_ens=size(x,2);
for i=1:num_risk
    
    for c=1:num_cat
        for j=1:num_ens
            % susceptibles
        x(num_out*num_risk*(c-1)+(i-1)*num_out+1,x(num_out*num_risk*(c-1)+(i-1)*num_out+1,j)-pop(i,j,c,1)>0)=pop(i,j,c,1);
        x(num_out*num_risk*(c-1)+(i-1)*num_out+9,x(num_out*num_risk*(c-1)+(i-1)*num_out+9,j)-pop(i,j,c,2)>0)=pop(i,j,c,2);
          % recovered
        x(num_out*num_risk*(c-1)+(i-1)*num_out+5,x(num_out*num_risk*(c-1)+(i-1)*num_out+5,j)-pop(i,j,c,1)>0)=pop(i,j,c,1);
        x(num_out*num_risk*(c-1)+(i-1)*num_out+13,x(num_out*num_risk*(c-1)+(i-1)*num_out+13,j)-pop(i,j,c,2)>0)=pop(i,j,c,2);
        end
        for j=1:num_out
            % rest of state variables, including S
            x(num_out*num_risk*(c-1)+(i-1)*num_out+j,x(num_out*num_risk*(c-1)+(i-1)*num_out+j,:)<0)=0;
        end
    end
end

% if parameters are not fixed, but estimated, put them back into
% initial prior range

for i=1:num_para
        if parabounds(i,1)~=parabounds(i,2)
            x(end-num_para+i,x(end-num_para+i,:)<xmin(i))=xmin(i)+(xmax(i)-xmin(i))*(0.1*rand(sum(x(end-num_para+i,:)<xmin(i)),1));
            x(end-num_para+i,x(end-num_para+i,:)>xmax(i))=xmax(i)-(xmax(i)-xmin(i))*(0.1*rand(sum(x(end-num_para+i,:)>xmax(i)),1));
        else
            x(end-num_para+i,:)=repmat(parabounds(i,1),1,num_ens);
        end
end


