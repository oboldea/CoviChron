% print tables and pictures with scenarios by risk
function tables_pictures_vax_percentage_age_risk(inf,hos,num_scen,num_times,v_frac,num_ens)
close all
load Data/pop
pop0=pop;
num_weeks = 24;
date1=1:1:num_weeks;
legd = {'0% all','50% 60+','25% HM <60, 50% 60+','25% HM <60, 75% 60+','50% HM <60, 50% 60+','50% HM <60, 75% 60+','75% HM <60, 75% 60+','25% HM<60, 50% 60-80, 75% 80+', '2023-2024'};

col1=rgb('Thistle');
col2=rgb('Plum');
col3=rgb("Violet");
col4=rgb("Fuchsia");
col5=rgb("DarkViolet");
col6 = rgb("BlueViolet");
col7 = rgb("DarkMagenta");
col8 = rgb("DarkSlateBlue");
col9 = rgb("MediumSlateBlue");
col10 = rgb("Indigo");
col=[col1;col2;col3;col4;col5;col6;col7;col8;col9;col10];
% 
% plot outbreak in H,M,L risk groups  and in total by 0-20, 20-60 and 60+
ix1=(1:1:3)';
ix2=(4:1:7)';
ix3=(8:1:11)';
xtitle={'[0,20)','[20,60)','60+'};
ytitle ={'High risk', 'Medium risk','Low risk','Total'};

figure(1)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
for i=1:4
    for cc=1:3
    subplot(4,3,3*(i-1)+cc)
         hold on
        box on
        ax = gca;
        ax.LineWidth = 2;
        if cc==1
            ylabel(ytitle(i))
        else
            ylabel('')
        end
               set(gca,'fontsize',20);
            for j=2:num_scen
                if cc==1
                    ix = ix1;
                elseif cc==2
                    ix = ix2;
                else
                    ix=ix3;
                end
                    post1 = squeeze(sum(hos(ix,:,i,:,:,j),[1 5]));
                    mean1=mean(post1,1);
                    plot(date1,cumsum(mean1(1,:)),'LineWidth',3,'color', col(j,:)); % plot mean fit from sum of unobservered updates 
                     if j==1
                     xlim([1 num_times]);
                     end
                    hold on;
                     if i==2
                     title(xtitle(cc));
                     end
                     tickVals = get(gca,'YTick');
                     newTickLabels = ThousandSep(tickVals);
                     set(gca,'YTickLabel',newTickLabels);
                     set(gca,'fontsize',20);
                     xlabel("weeks");
            end
    end
end
hold on;
legd2=legd(2:end);
lgd=legend(legd2,'Location','bestoutside','Fontsize',15,'Orientation','horizontal');

set(lgd,...
      'Position',[0.210244172914133 0.966019823342786 0.570833323445792 0.0319988445215172]);
% table

legd = {'0\% all','50\% 60+','25\% HM <60, 50\% 60+','25\% HM <60, 75\% 60+','50\% HM <60, 50\% 60+','50\% HM <60, 75\% 60+','75\% HM <60, 75\% 60+','25\% HM<60, 50\% 60-80, 75\% 80+','2023-2024'};
label1=["Scenario","Total/pop","Relative change","Peak new","Hosp/pop","Relative change","Vaccines/hosp avoided"];
sc=1;
[max_hos,ix] =max(squeeze(mean(squeeze(sum(hos(:,:,4,:,:,:),[1 5])),1)),[],1);
hos_sum = squeeze(sum(hos(:,:,4,:,:,:),[1,4,5]));
mean_hos_sum1 = mean(hos_sum,1);
mean_hos_sum2 =  -mean((hos_sum -repmat(hos_sum(:,1),1,num_scen))./repmat(hos_sum(:,1),1,num_scen),1);
inf_sum = squeeze(sum(inf(:,:,4,:,:,:),[1,4,5]));
mean_inf_sum1 =sc*mean(inf_sum,1)/sum(pop0,"all");
mean_inf_sum2 = -sc*mean((inf_sum -repmat(inf_sum(:,1),1,num_scen))./repmat(inf_sum(:,1),1,num_scen),1);
vax_used = squeeze(sum(v_frac.*repmat(pop0,1,1,num_scen),[1,2]));
q1=0.1; q2=0.9;
max_hos_quantile = zeros(2,num_scen); % 25% and 75% quantiles
hos_sum1_quantile = zeros(2,num_scen);
hos_sum2_quantile = zeros(2,num_scen);
inf_sum1_quantile = zeros(2,num_scen);
inf_sum2_quantile = zeros(2,num_scen);
for i=1:num_scen
hos_sum1_quantile(1,:) = sc*quantile(hos_sum,q1);
hos_sum1_quantile(2,:) = quantile(hos_sum,q2);
hos_sum2_quantile(1,:) = -sc*quantile((hos_sum - repmat(hos_sum(:,1),1,num_scen))./repmat(hos_sum(:,1),1,num_scen),q2);
hos_sum2_quantile(2,:) = -sc*quantile((hos_sum - repmat(hos_sum(:,1),1,num_scen))./repmat(hos_sum(:,1),1,num_scen),q1);
inf_sum1_quantile(1,:) = sc*quantile(inf_sum,q1)/sum(pop0,"all");
inf_sum1_quantile(2,:) = sc*quantile(inf_sum,q2)/sum(pop0,"all");
inf_sum2_quantile(1,:) = -sc*quantile((inf_sum - repmat(inf_sum(:,1),1,num_scen))./repmat(inf_sum(:,1),1,num_scen),q2);
inf_sum2_quantile(2,:) = -sc*quantile((inf_sum - repmat(inf_sum(:,1),1,num_scen))./repmat(inf_sum(:,1),1,num_scen),q1);
max_hos_quantile(1,i) = quantile(squeeze(sum(hos(:,:,4,ix(i),:,i),[1 5])),q1);
max_hos_quantile(2,i) = quantile(squeeze(sum(hos(:,:,4,ix(i),:,i),[1 5])),q2);
end
% calculate vaccines used to avoid one hospitalization
vax_quant = round(repmat(vax_used',num_ens,1)./(repmat(hos_sum(:,1),1,num_scen)-hos_sum));
vax_used2 = zeros(3,num_scen);
vax_used2(3,:)=mean(vax_quant,1);
vax_used2(1,:)=quantile(vax_quant,q1);
vax_used2(2,:)=quantile(vax_quant,q2);

%fidc=fopen('burden.m','wt');
fprintf('--------------------------------------------------------\n');
fprintf('%s & %s & %s & %s & %s& %s & %s\n',label1);
lab = ["10\%","90\%","Mean"];
popt = sum(pop0,"all");
for i=1:num_scen
    if i==1
         fprintf(' %s & %s & %1.2f & %s & %5.0f & %1.4f & %s & %s & %s\n',legd{i},lab(3),mean_inf_sum1(:,i),"-",round(max_hos(:,i)/100,0)*100,mean_hos_sum1(:,i)/popt,"-","-","-");
             for j=1:2
             fprintf(' & %s &  %1.2f & %s & %5.0f & %1.4f & %s &%s&\n',lab(j),inf_sum1_quantile(j,i),"-",round(max_hos_quantile(j,i)/100,0)*100,hos_sum1_quantile(j,i)/popt,"-","-");
             end
    else
         fprintf(' %s & %s & %1.2f & %1.2f & %5.0f & %1.4f & %1.2f & %6.0f &%1.2f\n',legd{i},lab(3),mean_inf_sum1(:,i),mean_inf_sum2(:,i),round(max_hos(:,i)/100,0)*100,mean_hos_sum1(:,i)/popt,mean_hos_sum2(:,i),vax_used2(3,i),vax_used(i)/popt);
             for j=1:2
             fprintf(' & %s &  %1.2f & %1.2f & %5.0f & %1.4f & %1.2f& %6.0f&\n',lab(j),inf_sum1_quantile(j,i),inf_sum2_quantile(j,i),round(max_hos_quantile(j,i)/100,0)*100,hos_sum1_quantile(j,i)/popt,hos_sum2_quantile(j,i),vax_used2(j,i));
             end
    end
end
for i=9:num_scen
  
         fprintf(' %s & %s & %1.2f & %1.2f & %5.0f & %1.4f & %1.2f & %6.0f &%1.2f\n',legd{i},lab(3),mean_inf_sum1(:,i),mean_inf_sum2(:,i),round(max_hos(:,i),0),mean_hos_sum1(:,i)/popt,mean_hos_sum2(:,i),vax_used2(3,i),vax_used(i)/popt);
             for j=1:2
             fprintf(' & %s &  %1.2f & %1.2f & %5.0f & %1.4f & %1.2f& %6.0f&\n',lab(j),inf_sum1_quantile(j,i),inf_sum2_quantile(j,i),round(max_hos_quantile(j,i),0),hos_sum1_quantile(j,i)/popt,hos_sum2_quantile(j,i),vax_used2(j,i));
             end

end
%fclose(fidc);
