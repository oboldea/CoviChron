% function SEIRHS_proj.m
% runs the  model and outputs updated variables and change of
% population from one set of compartments to the second set
% INPUTS
% x                     : (num_out x num_risk x num_cat +num_para) x num_ens prior of state
%                          variables and parameters, after inflation 
% x contains the following state variables in order, per region and then
% per age category, then at the end parameters are appended
%%% first - naive compartment
% 1 S susceptibles
% 2 E exposed
% 3 I infected 
% 4 H hospitalized patients
% 5 R Recovered
% 6 new cases
% 7 Hobs new hospitalizations
% 8 Rnew newly recovered people
%%% second - vaccinated or previously infected and waned compartment 
% 9 S susceptibles
% 10 E exposed
% 11 I documented infected
% 12 H hospitalized patients
% 13 R Recovered
% 14 new cases
% 15 Hobs new hospitalizations
% 16 Wnew Waned people in the current period in the first compartment set
% 17 Rnew Recovered people in the current period
% 18 WunV The pool of waned people that are not yet vaccinated
% pop               : num_risk x num_ens x num_cat x2, prior population in each
%                     risk /age category for the 2 sets of compartments: naive and vaccinated
%                     or previously infected
% ts                : scalar, time at which to evaluate 
% cont         : num_cat x num_risk x num_cat x num_risk , data: load total contact
%                    
% num_out           : scalar, number of state variable per age x risk that
%                     are updated
% ve                : 4x4 matrix, columns: protection against I, TR|I, TU|I, HUNC
%                     in the second set of compartments, over rows: Alpha,
%                     Delta, Waned, Booster
% delta             : num_cat x1 hospital discharge rates 
% VX                : 1 x num_risk x num_cat data, number of fully
%                     vaccinated per risk and age category at time ts
% para              : num_para x num_ens parameter posteriors 
% num_times         : number of weeks to project forward
% p1_inf            : num_cat x num_risk protection against infection in
%                     with no recent vaccination
% p1_hos            : num_cat x num_risk protection against hospitalization
%                     given infection with no recent vaccination
% p2_inf            : num_cat x num_risk protection against infection in
%                     with recent vaccination
% p2_hos            : num_cat x num_risk protection against hospitalization
%                     given infection with recent vaccination
% OUTPUT
% x                 : (num_out x num_risk x num_cat +num_para) x num_ens
%                     after evolution through 1 day SEIRHS model
% pop               : num_risk x num_ens x num_cat x2, population in each
%                     risk /age category for the 2 sets of compartments: naive and vaccinated
%                     or previously infected after SEIRHS transition
function [x,pop]=SEIRHS_proj(x,pop,ts,contacts,num_out,delta,VX,num_ens,pop0,p1_inf,p1_hos,p2_inf,p2_hos)

% add variants that increase transmissibility based on genetic data

frac_increase = 1.3*1.5*1.4; %Omicron BA.1/BA.2 raised infectiousness
cont = frac_increase*contacts;
dt=1;
% time step
tmstep=1; 
num_risk=size(pop,1);
num_cat=size(pop,3);
%index of variables S,E,I, H, new cases, new hospitalizations and
%parameters in the first and second set (V stands for second set of
%compartments, vaccinated or previously infected and waned)
Sidx    =(1:num_out:num_out*num_risk)';          % susceptibles
Eidx    =(2:num_out:num_out*num_risk)';          % exposed
Iidx   =(3:num_out:num_out*num_risk)';          % infected
Hidx    =(4:num_out:num_out*num_risk)';          % hospitalized patients
Ridx    =(5:num_out:num_out*num_risk)';          % Recovered
obsidx =(6:num_out:num_out*num_risk)';    % new confirmed cases
Hobsidx   =(7:num_out:num_out*num_risk)';      % new hospitalizations
Rnewidx    =(8:num_out:num_out*num_risk)';      % Recovered people in the current period
SVidx   =(9:num_out:num_out*num_risk)';         % susceptibles
EVidx   =(10:num_out:num_out*num_risk)';         % exposed
IVidx  =(11:num_out:num_out*num_risk)';         % infected
HVidx   =(12:num_out:num_out*num_risk)';         % hospitalized patients
RVidx    =(13:num_out:num_out*num_risk)';        % Recovered - can also be deleted
obsVidx =(14:num_out:num_out*num_risk)';    % new confirmed cases
HobsVidx   =(15:num_out:num_out*num_risk)';      % new hospitalizations
Wnewidx    =(16:num_out:num_out*num_risk)';      % Waned people in the current period
RVnewidx    =(17:num_out:num_out*num_risk)';      % Recovered people in the current period
WunVidx= (18:num_out:num_out*num_risk)';         % The pool of waned people that are not yet vaccinated

num_s=num_out*num_risk*num_cat;  % total number of state variables not including parameters

%initializing and retrieving parameters; allow for some
%parameters to differ across categories
epsidx           =2:4;
gammalowidx     =(9:19)'-4; % gamma low risk up to age 90+ (first 11 elements of gamma)
gammahighidx    =(20:23)'-4; % gamma high/med risk
Zidx            =24-4;
Didx            =25-4;
etaidx          =26-4;
% replicate eps for other age categories, multiplying by relative susc

epsi            = x(num_s+epsidx(end),:);
eps2            = x(num_s+epsidx(2),:).*epsi;
eps1            = x(num_s+epsidx(1),:).*epsi;
eps             = [repmat(eps1,3,1);repmat(eps2,4,1);repmat(epsi,4,1)];
% replicate it to be the same for risk groups (format:
% num_risk x num_ens x num_cat)
eps  = repmat(permute(eps,[3 2 1]),num_risk,1,1);
% do the same for hospitalization rates: low/medium/high same for
gamma_low = x(num_s+gammalowidx,:);
gamma_high = [repmat(x(num_s+gammahighidx(1),:),5,1);repmat(x(num_s+gammahighidx(2),:),2,1);repmat(x(num_s+gammahighidx(3),:),2,1);repmat(x(num_s+gammahighidx(4),:),2,1)].*gamma_low;
gamma = zeros(num_risk,num_ens,num_cat);
gamma(1,:,:)    = permute(gamma_high,[3 2 1]);
gamma(2,:,:)    = gamma(1,:,:);
gamma(3,:,:)    = permute(gamma_low,[3 2 1]);
Z               = x(num_s+Zidx,1);  % fixed, take first element
D               = x(num_s+Didx,1);  % fixed, take first element
etaA            = x(num_s+etaidx,:);

eta = cat(4,repmat(etaA,num_risk,1,num_cat),repmat(etaA,num_risk,1,num_cat));

% fourth dimension vax is compartment set
vax=2;
S     = zeros(num_risk,num_ens,num_cat,vax,tmstep+1);
E     = zeros(num_risk,num_ens,num_cat,vax,tmstep+1);
I    = zeros(num_risk,num_ens,num_cat,vax,tmstep+1);
H     = zeros(num_risk,num_ens,num_cat,vax,tmstep+1);
R     = zeros(num_risk,num_ens,num_cat,vax,tmstep+1);
WunV  =  zeros(num_risk,num_ens,num_cat,tmstep+1);
obs   = zeros(num_risk,num_ens,num_cat,vax);
Hobs  = zeros(num_risk,num_ens,num_cat,vax);
Rnew     = zeros(num_risk,num_ens,num_cat,vax);
Wnew     = zeros(num_risk,num_ens,num_cat);


for c=1:num_cat
    S(:,:,c,1,1)  = x((c-1)*num_out*num_risk+Sidx,:);
    E(:,:,c,1,1)  = x((c-1)*num_out*num_risk+Eidx,:);
    I(:,:,c,1,1) = x((c-1)*num_out*num_risk+Iidx,:);
    H(:,:,c,1,1)  = x((c-1)*num_out*num_risk+Hidx,:);
    R(:,:,c,1,1)  = x((c-1)*num_out*num_risk+Ridx,:);
    WunV(:,:,c,1) = x((c-1)*num_out*num_risk+WunVidx,:);
    S(:,:,c,2,1)  = x((c-1)*num_out*num_risk+SVidx,:);
    E(:,:,c,2,1)  = x((c-1)*num_out*num_risk+EVidx,:);
    I(:,:,c,2,1)  = x((c-1)*num_out*num_risk+IVidx,:);
    H(:,:,c,2,1)  = x((c-1)*num_out*num_risk+HVidx,:);
    R(:,:,c,2,1)  = x((c-1)*num_out*num_risk+RVidx,:);
end

VX_percent=zeros(num_risk,num_ens,num_cat);

%Step 0: deterministic vaccination
for c=1:num_cat
    % vaccinations in S,E,R category
    VX_cat = permute(repmat(VX(1,:,c),1,1,num_ens),[2 3 1]); %number of newly vaccinated people is constant for ensembles
    notvac=I(:,:,c,1,1)+H(:,:,c,1,1); % documented cases and hospitalized people do not get vaccinated
    VX_prelim = max(VX_cat./(pop(:,:,c,1)-notvac+WunV(:,:,c,1)),0);
    VX_prelim(isinf(VX_prelim)|isnan(VX_prelim))=0;
    VX_percent(:,:,c)=VX_prelim;%The percent of population that got vaccinated in day t
    % all people of other types are getting vaccinated with the same rate
    Svx = VX_prelim.*S(:,:,c,1,1);
    Evx = VX_prelim.*E(:,:,c,1,1);
    Rvx = VX_prelim.*R(:,:,c,1,1);
    WunV(:,:,c,2)=WunV(:,:,c,1)-VX_prelim.*WunV(:,:,c,1);
    Svx=max(Svx,0);Evx=max(Evx,0);Rvx=max(Rvx,0);WunV=max(WunV,0);
        % vaccinated people are removed from compartment set v=1 and added to compartment set v=2
       for v=1:vax
          S(:,:,c,v,1)=S(:,:,c,v,1)+(-1)^v*Svx;
        E(:,:,c,v,1)=E(:,:,c,v,1)+(-1)^v*Evx;
        R(:,:,c,v,1)=R(:,:,c,v,1)+(-1)^v*Rvx;
        pop(:,:,c,v)=round(S(:,:,c,v,1)+E(:,:,c,v,1)+I(:,:,c,v,1)+H(:,:,c,v,1)+R(:,:,c,v,1));
       end
end


% vaccine effectiveness
ve1_inf = repmat(permute(1-p1_inf,[2,3,1]),1,num_ens,1);
ve1_hos = repmat(permute(1-p1_hos,[2,3,1]),1,num_ens,1);
ve2_inf = repmat(permute(1-p2_inf,[2,3,1]),1,num_ens,1);
ve2_hos = repmat(permute(1-p2_hos,[2,3,1]),1,num_ens,1);
gamma = repmat(gamma,1,1,1,vax); % calculate differential hosp rates across vax and non-vax compartments

    gamma(:,:,:,1) = gamma(:,:,:,1).*ve1_hos;
    gamma(:,:,:,2) = gamma(:,:,c,1).*ve2_hos;


%  SEIRHS metapopulation model
tcnt=0;
for t=ts+dt:dt:ts+tmstep
    tcnt=tcnt+1;
%start SEIRHS with RK4 numerical integration

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RK step 1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% calculate force of infection plus hospitalization rate protections differential across ages outside step to speed up computation
beta = zeros(num_risk,num_ens,num_cat,vax);
for c=1:num_cat
    for i=1:num_risk
    force = repmat(permute(squeeze(cont(c,i,:,:)/sum(pop0,"all")),[2,3,1]),1,num_ens,1).*eps; % transmission force, reshape beta as num_risk x num_ens x num_cat for each c
    beta(i,:,c,1) = sum(force.*(I(:,:,:,1,1)+I(:,:,:,2,1)),[1,3]).*ve1_inf(i,:,c);
    beta(i,:,c,2) = beta(i,:,c,1).*ve2_inf(i,:,c);
    end
end

    % calculate transmission force for the two compartment sets, epsilon time lambda
    % starting SEIRHS
    Eexp = dt*beta.*S(:,:,:,:,1);       % exposed
    Einf=  dt*(1/Z)*E(:,:,:,:,1);        % latent that become infectious
    Erec= dt*(1/D)*I(:,:,:,:,1);        % infected removed without hospitalization
    Ehos= dt*gamma.*I(:,:,:,:,1);        % infected that become hospitalized
    Erech=  dt*delta.*H(:,:,:,:,1);      % hospitalized recovered
    Ewaned= dt*eta.*R(:,:,:,:,1);        % newly waned

    %Each value must be positive
    Eexp=max(Eexp,0);Einf=max(Einf,0);Erec=max(Erec,0);Erech=max(Erech,0); Ehos=max(Ehos,0);Ewaned=max(Ewaned,0);
    % ruling out the possibility of NaN values because of division by
    % population of 0 in vaccinated cases
    Eexp(isinf(Eexp)|isnan(Eexp)) = 0;
    Einf(isinf(Einf)|isnan(Einf)) = 0;
    Erec(isinf(Erec)|isnan(Erec)) = 0;Erech(isinf(Erech)|isnan(Erech)) = 0;
    Ehos(isinf(Ehos)|isnan(Ehos))    = 0; Ewaned(isinf(Ewaned)|isnan(Ewaned))    = 0;
    %%%%%%%%%%stochastic version
    % Eexp=poissrnd(Eexp);
    % Einf=poissrnd(Einf);
    % Erec=poissrnd(Erec);Erech=poissrnd(Erech);
    % Ehos=poissrnd(Ehos);Ewaned=poissrnd(Ewaned);

    % evolution equation in the SEIR model
    sk1 =-Eexp;
    ek1 =Eexp-Einf;
    ik1=Einf-Erec-Ehos;
    hk1=Ehos-Erech;
    rk1=Erec+Erech;
    % add new cases for vaccinated and non-vaccinated, only their sum is observed
    ik1i=Einf;
    hk1i=Ehos;
    wk1=Ewaned; % newly waned

   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RK step 2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Ts=S(:,:,:,:,1)+sk1/2;
    Ts(:,:,:,2)=Ts(:,:,:,2)+sum(wk1/2,4); % newly waned go into vax S
    Te=E(:,:,:,:,1)+ek1/2;
    Ti=I(:,:,:,:,1)+ik1/2;
    Tir=R(:,:,:,:,1)+rk1/2-wk1/2;
    Tih=H(:,:,:,:,1)+hk1/2;

    S(:,:,:,:,2)=S(:,:,:,:,2)+sk1/6;
    S(:,:,:,2,2)=S(:,:,:,2,2)+sum(wk1/6,4);
    E(:,:,:,:,2)=E(:,:,:,:,2)+ek1/6;
    I(:,:,:,:,2)=I(:,:,:,:,2)+ik1/6;
    H(:,:,:,:,2)=H(:,:,:,:,2)+hk1/6;
    R(:,:,:,:,2)=R(:,:,:,:,2)+rk1/6-wk1/6;
    obs=obs+ik1i/6;
    Hobs=Hobs+hk1i/6;
    Wnew=Wnew+wk1/6;
    Rnew=Rnew+rk1/6;
% calculate force of infection outside step to speed up computation
beta = zeros(num_risk,num_ens,num_cat,vax);

for c=1:num_cat
    for i=1:num_risk
    force = repmat(permute(squeeze(cont(c,i,:,:)),[2,3,1]),1,num_ens,1).*eps; % transmission force, reshape beta as num_risk x num_ens x num_cat for each c
    beta(i,:,c,1) = sum(force.*(Ti(:,:,:,1)+Ti(:,:,:,2))./sum(pop,4),[1,3]).*ve1_inf(i,:,c);
    beta(i,:,c,2) = beta(i,:,c,1).*ve2_inf(i,:,c);
    end
end

    % calculate transmission force for the two compartment sets, epsilon time lambda
    % starting SEIRHS
    Eexp =  dt*beta.*Ts;                  % exposed
    Einf=  dt*(1/Z)*Te;                   % latent that become infectious
    Erec= dt*(1/D)*Ti(:,:,:,:,1);        % infected removed without hospitalization
    Ehos= dt*gamma.*Ti(:,:,:,:,1);        %infected that become hospitalized
    Erech=  dt*delta.*Tih(:,:,:,:,1);     % hospitalized recovered
    Ewaned= dt*eta.*Tir(:,:,:,:,1);       % newly waned

    %Each value must be positive
    Eexp=max(Eexp,0);Einf=max(Einf,0);Erec=max(Erec,0);Erech=max(Erech,0); Ehos=max(Ehos,0);Ewaned=max(Ewaned,0);
    % ruling out the possibility of NaN values because of division by
    % population of 0 in vaccinated cases
    Eexp(isinf(Eexp)|isnan(Eexp)) = 0;
    Einf(isinf(Einf)|isnan(Einf)) = 0;
    Erec(isinf(Erec)|isnan(Erec)) = 0;Erech(isinf(Erech)|isnan(Erech)) = 0;
    Ehos(isinf(Ehos)|isnan(Ehos))    = 0; Ewaned(isinf(Ewaned)|isnan(Ewaned))    = 0;
    %%%%%%%%%%stochastic version
    % Eexp=poissrnd(Eexp);
    % Einf=poissrnd(Einf);
    % Erec=poissrnd(Erec);Erech=poissrnd(Erech);
    % Ehos=poissrnd(Ehos);Ewaned=poissrnd(Ewaned);

    % evolution equation in the SEIR model
    sk1 =-Eexp;
    ek1 =Eexp-Einf;
    ik1=Einf-Erec-Ehos;
    hk1=Ehos-Erech;
    rk1=Erec+Erech;
    % add new cases for vaccinated and non-vaccinated, only their sum is observed
    ik1i=Einf;
    hk1i=Ehos;
    wk1=Ewaned; % newly waned

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RK step 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Ts=S(:,:,:,:,1)+sk1/2;
    Ts(:,:,:,2)=Ts(:,:,:,2)+sum(wk1/2,4); % newly waned go into vax S
    Te=E(:,:,:,:,1)+ek1/2;
    Ti=I(:,:,:,:,1)+ik1/2;
    Tir=R(:,:,:,:,1)+rk1/2-wk1/2;
    Tih=H(:,:,:,:,1)+hk1/2;

    S(:,:,:,:,2)=S(:,:,:,:,2)+sk1/3;
    S(:,:,:,2,2)=S(:,:,:,2,2)+sum(wk1/3,4);
    E(:,:,:,:,2)=E(:,:,:,:,2)+ek1/3;
    I(:,:,:,:,2)=I(:,:,:,:,2)+ik1/3;
    H(:,:,:,:,2)=H(:,:,:,:,2)+hk1/3;
    R(:,:,:,:,2)=R(:,:,:,:,2)+rk1/3-wk1/3;
    obs=obs+ik1i/3;
    Hobs=Hobs+hk1i/3;
    Wnew=Wnew+wk1/3;
    Rnew=Rnew+rk1/3;
% calculate force of infection outside step to speed up computation
beta = zeros(num_risk,num_ens,num_cat,vax);
for c=1:num_cat
    for i=1:num_risk
    force = repmat(permute(squeeze(cont(c,i,:,:)),[2,3,1]),1,num_ens,1).*eps; % transmission force, reshape beta as num_risk x num_ens x num_cat for each c
    beta(i,:,c,1) = sum(force.*(Ti(:,:,:,1)+Ti(:,:,:,2))./sum(pop,4),[1,3]).*ve1_inf(i,:,c);
    beta(i,:,c,2) = beta(i,:,c,1).*ve2_inf(i,:,c);
    end
end

    % calculate transmission force for the two compartment sets, epsilon time lambda
    % starting SEIRHS
    Eexp =  dt*beta.*Ts;                  % exposed
    Einf=  dt*(1/Z)*Te;                   % latent that become infectious
    Erec= dt*(1/D)*Ti(:,:,:,:,1);        % infected removed without hospitalization
    Ehos= dt*gamma.*Ti(:,:,:,:,1);        %infected that become hospitalized
    Erech=  dt*delta.*Tih(:,:,:,:,1);     % hospitalized recovered
    Ewaned= dt*eta.*Tir(:,:,:,:,1);       % newly waned

    %Each value must be positive
    Eexp=max(Eexp,0);Einf=max(Einf,0);Erec=max(Erec,0);Erech=max(Erech,0); Ehos=max(Ehos,0);Ewaned=max(Ewaned,0);
    % ruling out the possibility of NaN values because of division by
    % population of 0 in vaccinated cases
    Eexp(isinf(Eexp)|isnan(Eexp)) = 0;
    Einf(isinf(Einf)|isnan(Einf)) = 0;
    Erec(isinf(Erec)|isnan(Erec)) = 0;Erech(isinf(Erech)|isnan(Erech)) = 0;
    Ehos(isinf(Ehos)|isnan(Ehos))    = 0; Ewaned(isinf(Ewaned)|isnan(Ewaned))    = 0;
     %%%%%%%%%%stochastic version
    % Eexp=poissrnd(Eexp);
    % Einf=poissrnd(Einf);
    % Erec=poissrnd(Erec);Erech=poissrnd(Erech);
    % Ehos=poissrnd(Ehos);Ewaned=poissrnd(Ewaned);

    % evolution equation in the SEIR model
    sk1 =-Eexp;
    ek1 =Eexp-Einf;
    ik1=Einf-Erec-Ehos;
    hk1=Ehos-Erech;
    rk1=Erec+Erech;
    % add new cases for vaccinated and non-vaccinated, only their sum is observed
    ik1i=Einf;
    hk1i=Ehos;
    wk1=Ewaned; % newly waned

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% RK step 4
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    Ts=S(:,:,:,:,1)+sk1;
    Ts(:,:,:,2)=Ts(:,:,:,2)+sum(wk1,4); % newly waned go into vax S
    Te=E(:,:,:,:,1)+ek1;
    Ti=I(:,:,:,:,1)+ik1;
    Tir=R(:,:,:,:,1)+rk1-wk1;
    Tih=H(:,:,:,:,1)+hk1;

    S(:,:,:,:,2)=S(:,:,:,:,2)+sk1/3;
    S(:,:,:,2,2)=S(:,:,:,2,2)+sum(wk1/3,4);
    E(:,:,:,:,2)=E(:,:,:,:,2)+ek1/3;
    I(:,:,:,:,2)=I(:,:,:,:,2)+ik1/3;
    H(:,:,:,:,2)=H(:,:,:,:,2)+hk1/3;
    R(:,:,:,:,2)=R(:,:,:,:,2)+rk1/3-wk1/3;
    obs=obs+ik1i/3;
    Hobs=Hobs+hk1i/3;
    Wnew=Wnew+wk1/3;
    Rnew=Rnew+rk1/3;
% calculate force of infection outside step to speed up computation
beta = zeros(num_risk,num_ens,num_cat,vax);
for c=1:num_cat
    for i=1:num_risk
    force = repmat(permute(squeeze(cont(c,i,:,:)),[2,3,1]),1,num_ens,1).*eps; % transmission force, reshape beta as num_risk x num_ens x num_cat for each c
    beta(i,:,c,1) = sum(force.*(Ti(:,:,:,1)+Ti(:,:,:,2))./sum(pop,4),[1,3]).*ve1_inf(i,:,c);
    beta(i,:,c,2) = beta(i,:,c,1).*ve2_inf(i,:,c);
    end
end

    % calculate transmission force for the two compartment sets, epsilon time lambda
    % starting SEIRHS
    Eexp =  dt*beta.*Ts;                  % exposed
    Einf=  dt*(1/Z)*Te;                   % latent that become infectious
    Erec= dt*(1/D)*Ti(:,:,:,:,1);        % infected removed without hospitalization
    Ehos= dt*gamma.*Ti(:,:,:,:,1);        %infected that become hospitalized
    Erech=  dt*delta.*Tih(:,:,:,:,1);     % hospitalized recovered
    Ewaned= dt*eta.*Tir(:,:,:,:,1);       % newly waned

    %Each value must be positive
    Eexp=max(Eexp,0);Einf=max(Einf,0);Erec=max(Erec,0);Erech=max(Erech,0); Ehos=max(Ehos,0);Ewaned=max(Ewaned,0);
    % ruling out the possibility of NaN values because of division by
    % population of 0 in vaccinated cases
    Eexp(isinf(Eexp)|isnan(Eexp)) = 0;
    Einf(isinf(Einf)|isnan(Einf)) = 0;
    Erec(isinf(Erec)|isnan(Erec)) = 0;Erech(isinf(Erech)|isnan(Erech)) = 0;
    Ehos(isinf(Ehos)|isnan(Ehos))    = 0; Ewaned(isinf(Ewaned)|isnan(Ewaned))    = 0;
    %%%%%%%%%%stochastic version
    % Eexp=poissrnd(Eexp);
    % Einf=poissrnd(Einf);
    % Erec=poissrnd(Erec);Erech=poissrnd(Erech);
    % Ehos=poissrnd(Ehos);Ewaned=poissrnd(Ewaned);

    % evolution equation in the SEIR model
    sk1 =-Eexp;
    ek1 =Eexp-Einf;
    ik1=Einf-Erec-Ehos;
    hk1=Ehos-Erech;
    rk1=Erec+Erech;
    % add new cases for vaccinated and non-vaccinated, only their sum is observed
    ik1i=Einf;
    hk1i=Ehos;
    wk1=Ewaned; % newly waned
   
    S(:,:,:,:,2)=S(:,:,:,:,2)+sk1/6;
    S(:,:,:,2,2)=S(:,:,:,2,2)+sum(wk1/6,4);
    E(:,:,:,:,2)=E(:,:,:,:,2)+ek1/6;
    I(:,:,:,:,2)=I(:,:,:,:,2)+ik1/6;
    H(:,:,:,:,2)=H(:,:,:,:,2)+hk1/6;
    R(:,:,:,:,2)=R(:,:,:,:,2)+rk1/6-wk1/6;
    obs=obs+ik1i/6;
    Hobs=Hobs+hk1i/6;
    Wnew=Wnew+wk1/6;
    Rnew=Rnew+rk1/6;

%     %%%%% Complete RK4 integration
    S(:,:,:,:,2)=round(S(:,:,:,:,2)+S(:,:,:,:,1));
    E(:,:,:,:,2)=round(E(:,:,:,:,2)+E(:,:,:,:,1));
    I(:,:,:,:,2)=round(I(:,:,:,:,2)+I(:,:,:,:,1));
    H(:,:,:,:,2)=round(H(:,:,:,:,2)+H(:,:,:,:,1));
    R(:,:,:,:,2)=round(R(:,:,:,:,2)+R(:,:,:,:,1));
    obs=round(obs); % not really observed, but these are newly infectives
    Hobs=round(Hobs);
    Wnew= round(Wnew);
    Rnew= round(Rnew);
end


%%%update x by distributing size into a large vector x
for c=1:num_cat
    x((c-1)*num_out*num_risk+Sidx,:)=S(:,:,c,1,2);
    x((c-1)*num_out*num_risk+Eidx,:)=E(:,:,c,1,2);
    x((c-1)*num_out*num_risk+Iidx,:)=I(:,:,c,1,2);
    x((c-1)*num_out*num_risk+Hidx,:)=H(:,:,c,1,2) ;
    x((c-1)*num_out*num_risk+Ridx,:)=R(:,:,c,1,1) ;  %%% We update R later and only need to know the level after vaccination
    x((c-1)*num_out*num_risk+obsidx,:)=obs(:,:,c,1) ;
    x((c-1)*num_out*num_risk+Hobsidx,:)=Hobs(:,:,c,1) ;
    x((c-1)*num_out*num_risk+Rnewidx,:)=Rnew(:,:,c,1) ;
    % fully vax
    x((c-1)*num_out*num_risk+SVidx,:)=S(:,:,c,2,2);
    x((c-1)*num_out*num_risk+EVidx,:)=E(:,:,c,2,2);
    x((c-1)*num_out*num_risk+IVidx,:)=I(:,:,c,2,2);
    x((c-1)*num_out*num_risk+HVidx,:)=H(:,:,c,2,2) ;
    x((c-1)*num_out*num_risk+RVidx,:)=R(:,:,c,2,1) ;
    x((c-1)*num_out*num_risk+obsVidx,:)=obs(:,:,c,2) ;
    x((c-1)*num_out*num_risk+HobsVidx,:)=Hobs(:,:,c,2) ;
    x((c-1)*num_out*num_risk+RVnewidx,:)=Rnew(:,:,c,2) ;
    x((c-1)*num_out*num_risk+Wnewidx,:)=Wnew(:,:,c,1);
    x((c-1)*num_out*num_risk+WunVidx,:)=WunV(:,:,c,2);

end
