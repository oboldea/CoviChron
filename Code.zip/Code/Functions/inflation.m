% function inflation.m 
% Variance inflates the previous posterior means to prevent filter collapse
% INPUT
% x                     : (num_out x num_risk x num_cat +num_para) x num_ens prior draws of state
%                          variables and parameters 
% pop                   : num_risk x num_ens x num_cat x2, population in each
%                         region /age category for the 2 sets of compartments: naive and vaccinated
%                         or previously infected
% lambda                : factor by which the posterior means are variance
%                         inflated
% parabounds            : num_para x2 lower and upper bounds of uniform parameter
%                         prior
% num_risk               : scalar, no. of risk categories
% num_out               : scalar, no. of state variable per age x region that
%                        are updated
% num_ens               : scalar, no. of ensembles
% num_para              : scalar, number of parameters to be estimated
% OUTPUT
% x                     : (num_out x num_risk x num_cat +num_para) x num_ens
%                           variance inflated prior
% x contains the following state variables in order, per region and then
% per age category, then at the end parameters are appended
%%% first - naive compartment
% 1 S susceptibles
% 2 E exposed
% 3 I infected 
% 4 H hospitalized patients
% 5 R Recovered
% 6 obs new confirmed cases
% 7 Hobs new hospitalizations
% 8 Rnew newly recovered people
%%% second - vaccinated or previously infected and waned compartment 
% 9 S susceptibles
% 10 E exposed
% 11 I documented infected
% 12 H hospitalized patients
% 13 R Recovered
% 14 obs new confirmed cases
% 15 Hobs new hospitalizations
% 16 Wnew Waned people in the current period
% 17 Rnew Recovered people in the current period
% 18 WunV The pool of waned people that are not yet vaccinated

     

function [x]=inflation(x,pop,lambda,parabounds,num_cat,num_risk,num_out,num_ens,num_para)


Sidx    =(1:num_out:num_out*num_risk)';          % susceptibles
Eidx    =(2:num_out:num_out*num_risk)';          % exposed
Iidx   =(3:num_out:num_out*num_risk)';          % infected
Hidx    =(4:num_out:num_out*num_risk)';          % hospitalized patients
Ridx    =(5:num_out:num_out*num_risk)';          % Recovered
Rnewidx =(8:num_out:num_out*num_risk)';          % Recovered people in the current period
% vaccinated or previously infected
SVidx   =(9:num_out:num_out*num_risk)';         % susceptibles
EVidx   =(10:num_out:num_out*num_risk)';         % exposed
IVidx  =(11:num_out:num_out*num_risk)';         % infected
HVidx   =(12:num_out:num_out*num_risk)';         % hospitalized patients
RVidx    =(13:num_out:num_out*num_risk)';        % Recovered - can also be deleted
Wnewidx    =(16:num_out:num_out*num_risk)';      % Waned people in the current period
RVnewidx    =(17:num_out:num_out*num_risk)';     % Recovered people in the current period
WunVidx= (18:num_out:num_out*num_risk)';         % The pool of waned people that are not yet vaccinated
for c=1:num_cat
    x((c-1)*num_out*num_risk+Eidx,:)=x((c-1)*num_out*num_risk+Eidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+Eidx,:)-mean(x((c-1)*num_out*num_risk+Eidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+Iidx,:)=x((c-1)*num_out*num_risk+Iidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+Iidx,:)-mean(x((c-1)*num_out*num_risk+Iidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+Hidx,:)=x((c-1)*num_out*num_risk+Hidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+Hidx,:)-mean(x((c-1)*num_out*num_risk+Hidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+EVidx,:)=x((c-1)*num_out*num_risk+EVidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+EVidx,:)-mean(x((c-1)*num_out*num_risk+EVidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+IVidx,:)=x((c-1)*num_out*num_risk+IVidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+IVidx,:)-mean(x((c-1)*num_out*num_risk+IVidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+HVidx,:)=x((c-1)*num_out*num_risk+HVidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+HVidx,:)-mean(x((c-1)*num_out*num_risk+HVidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+Ridx,:)=x((c-1)*num_out*num_risk+Ridx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+Rnewidx,:)-mean(x((c-1)*num_out*num_risk+Rnewidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+RVidx,:)=x((c-1)*num_out*num_risk+RVidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+RVnewidx,:)-mean(x((c-1)*num_out*num_risk+RVnewidx,:),2)*ones(1,num_ens));
    x((c-1)*num_out*num_risk+WunVidx,:)=x((c-1)*num_out*num_risk+WunVidx,:)+(lambda-1)*(x((c-1)*num_out*num_risk+Wnewidx,:)-mean(x((c-1)*num_out*num_risk+Wnewidx,:),2)*ones(1,num_ens));

end


x(end-num_para+1:end,:)=x(end-num_para+1:end,:)+(lambda-1)*(x(end-num_para+1:end,:)-mean(x(end-num_para+1:end,:),2)*ones(1,num_ens));


x=checkbound(x,pop,parabounds,num_cat,num_out); %it is needed before updating for S, since there can be some some negative observations after inflation

% calculate currently susceptible S as remainder
for c=1:num_cat
    x((c-1)*num_out*num_risk+Sidx,:)=pop(:,:,c,1)- x((c-1)*num_out*num_risk+Eidx,:)-x((c-1)*num_out*num_risk+Iidx,:)-x((c-1)*num_out*num_risk+Hidx,:)-x((c-1)*num_out*num_risk+Ridx,:);
    x((c-1)*num_out*num_risk+SVidx,:)=pop(:,:,c,2)- x((c-1)*num_out*num_risk+EVidx,:)-x((c-1)*num_out*num_risk+IVidx,:)-x((c-1)*num_out*num_risk+HVidx,:)-x((c-1)*num_out*num_risk+RVidx,:);
end

% calculate currently recovered R as remainder, due to newly recovered and newly waned being updated rather
% than R
for c=1:num_cat
    for i=1:num_risk
        for j=1:num_ens
            if x(num_out*num_risk*(c-1)+(i-1)*num_out+1,j)<0
            x(num_out*num_risk*(c-1)+(i-1)*num_out+1,j)=0;
            x(num_out*num_risk*(c-1)+(i-1)*num_out+5,j)=pop(i,j,c,1)-x(num_out*num_risk*(c-1)+(i-1)*num_out+4,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+3,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+2,j);
            end
            if x(num_out*num_risk*(c-1)+(i-1)*num_out+9,j)<0
            x(num_out*num_risk*(c-1)+(i-1)*num_out+9,j)=0;
            x(num_out*num_risk*(c-1)+(i-1)*num_out+13,j)=pop(i,j,c,2)-x(num_out*num_risk*(c-1)+(i-1)*num_out+12,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+11,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+10,j);
            end
            if x(num_out*num_risk*(c-1)+(i-1)*num_out+5,j)<0
                x(num_out*num_risk*(c-1)+(i-1)*num_out+5,j)=0;
             % x(num_out*num_risk*(c-1)+(i-1)*num_out+13,j)=pop(i,j,c,2)-x(num_out*num_risk*(c-1)+(i-1)*num_out+12,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+11,j)-x(num_out*num_risk*(c-1)+(i-1)*num_out+10,j);
            end
        end
    end
end

end