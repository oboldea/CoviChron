% function checkbound_week.m
% checks if values of variables are reasonable
% makes sure the posterior of unobserved vartiables sum back to the
% posterior of the observed variables
% INPUTS
% x_u            : (1xnum_riskxnum_cat) x num_ens matrix of posteriors
%                   of unobservable hospitalizations in all age and risk groups and 2
%                   compartment sets; ordered by compartment set, then by
%                   risk, then by age
% x_o           : (num_cat-1) x num_ens matrix of posteriors of observable
%                   hospitalizations which are sums of the unosbervable
%                   ones
% OUTPUT
% x_u            : (1xnum_riskxnum_cat) x num_ens matrix of posteriors
%                   of unobservable hospitalizations in all age and risk groups and 2
%                   compartment sets; ordered by compartment set, then by
%                   risk, then by age
% x_o           : (num_cat-1) x num_ens matrix of posteriors of observable
%                   hospitalizations which are sums of the unosbervable
%                   ones
function [x_u, x_o] = checkbound_week(x_u,x_o)

num_ens=size(x_u,2);
n_o = size(x_o,1);
n_u = size(x_u,1);
% set negative hospitalization updates to zero
 for c=1:n_o
            for e=1:num_ens
                    if x_o(c,e)<0 
                        x_o(c,e)=0;
                    end    
            end
 end
 for j=1:n_u
            for e=1:num_ens
                    if x_u(j,e)<0 
                        x_u(j,e)=0;
                    end    
            end
 end
 



