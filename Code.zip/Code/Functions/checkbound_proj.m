% function checkbound_proj.m
% checks if values of variables are reasonable: do not exceed population, are non-negative
% checks if initial priors lead to unreasonable values of S
% INPUTS
% x             : (num_out x num_risk x num_cat +num_para) x num_ens prior draws of state
%                  variables and parameters
% pop                 : num_risk x num_ens x num_cat x2, population in each
%                       region /age category for the 2 sets of compartments: naive and vaccinated
%                       or previously infected
% num_cat       : scalar, no. of age categories
% num_out       : scalar, number of state variable per age x risk that
%                 are updated
% OUTPUT
% x             : (num_out x num_risk x num_cat +num_para) x num_ens bound corrected prior draws of state
%                  variables and parameters

function x = checkbound_proj(x,pop,num_cat,num_out)


num_risk=size(pop,1);
num_ens=size(x,2);
for i=1:num_risk
    
    for c=1:num_cat
        for j=1:num_ens
            % only susceptibles
        x(num_out*num_risk*(c-1)+(i-1)*num_out+1,x(num_out*num_risk*(c-1)+(i-1)*num_out+1,j)-pop(i,j,c,1)>0)=pop(i,j,c,1);
        x(num_out*num_risk*(c-1)+(i-1)*num_out+9,x(num_out*num_risk*(c-1)+(i-1)*num_out+9,j)-pop(i,j,c,2)>0)=pop(i,j,c,2);
          % recovered
        x(num_out*num_risk*(c-1)+(i-1)*num_out+5,x(num_out*num_risk*(c-1)+(i-1)*num_out+5,j)-pop(i,j,c,1)>0)=pop(i,j,c,1);
        x(num_out*num_risk*(c-1)+(i-1)*num_out+13,x(num_out*num_risk*(c-1)+(i-1)*num_out+13,j)-pop(i,j,c,2)>0)=pop(i,j,c,2);
        end
        for j=1:num_out
            % rest of state variables, including S
            x(num_out*num_risk*(c-1)+(i-1)*num_out+j,x(num_out*num_risk*(c-1)+(i-1)*num_out+j,:)<0)=0;
        end
    end
end





