% function checkbound_ini.m
% checks if initial priors lead to unreasonable values of S
% INPUTS
% x             : (num_out x num_risk x num_cat +num_para) x num_ens prior draws of state
%                  variables and parameters
% pop                 : num_risk x num_ens x num_cat x2, population in each
%                       region /age category for the 2 sets of compartments: naive and vaccinated
%                       or previously infected
% num_cat       : scalar, no. of age categories
% num_out       : scalar, number of state variable per age x region that
%                 are updated
% OUTPUT
% x             : (num_out x num_risk x num_cat +num_para) x num_ens bound corrected prior draws of state
%                  variables and parameters 
function x = checkbound_ini(x,pop,num_cat,num_out)

num_risk=size(pop,2);

for i=1:num_risk

    for c=1:num_cat
        %S
        %S non-vaccinated
        x(num_out*num_risk*(c-1)+(i-1)*num_out+1,x(num_out*num_risk*(c-1)+(i-1)*num_out+1,:)<0)=0;
        x(num_out*num_risk*(c-1)+(i-1)*num_out+1,x(num_out*num_risk*(c-1)+(i-1)*num_out+1,:)>pop(c,i))=pop(c,i);
        % Recovered
        x(num_out*num_risk*(c-1)+(i-1)*num_out+10,x(num_out*num_risk*(c-1)+(i-1)*num_out+5,:)<0)=0; 
        x(num_out*num_risk*(c-1)+(i-1)*num_out+10,x(num_out*num_risk*(c-1)+(i-1)*num_out+5,:)>pop(c,i))=pop(c,i); 
            for j=1:num_out
            % rest of state variables
            x(num_out*num_risk*(c-1)+(i-1)*num_out+j,x(num_out*num_risk*(c-1)+(i-1)*num_out+j,:)<0)=0;
            end
    end
end
