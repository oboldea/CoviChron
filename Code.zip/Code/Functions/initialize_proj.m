% function initialize_proj.m
% initialize population in the second compartment set assuming vaccines are
% administered all at once
% INPUTS
% pop0          : num_cat x num_risk matrix of population in age-risk group
% num_ens       : number of initial ensemble draws
% num_out   	: number of compartments (state variable) for a given risk
%                  group and age category
% v_frac        : num_cat x num_risk vaccination coverage by age and
%                     risk administered before projection 
% para          : num_para x num_ens parameter posteriors 
% OUTPUTS
% x             : (num_var+num_para) x num_ens matrix, all initializations
%                 for variables and parameters
% pop           : num_risk x num_ens x num_cat x 2 array. The forth dimension refers to compartment sets


function [x,pop]=initialize_proj(pop0,num_ens,num_out,v_frac,para)
% retrieve relevant dimensions of data
[num_cat, num_risk]          = size(pop0);
num_para                    = size(para,1);
% initialize variables and parameters
x                           = zeros(num_out*num_risk*num_cat+num_para,num_ens);

x(end-num_para+1:end,:)    = para;
range                      = para(1,1);
% calculate the fraction of population in each risk-age group
N                           = sum(sum(pop0,1),2);
frac_pop                    = (pop0/N)'; 
pop0                        = pop0';
% distribute initial range based on populations size
v_frac                      =v_frac';
range1                      = round(range*(1-v_frac).*frac_pop);
range2                      =round(range*v_frac.*frac_pop);
pop1                      = round((1-v_frac).*pop0);
pop2                      = round(v_frac.*pop0);
% distribute at population shares the initial range draws
Sidx1                        = (1:num_out:num_out*num_risk)';      % susceptibles
Sidx2                       = (9:num_out:num_out*num_risk);
% distribute at population shares the initial range draws
Eidx1                        = (2:num_out:num_out*num_risk)';      % exposed
Eidx2                       = (10:num_out:num_out*num_risk);
Iidx1                        = (3:num_out:num_out*num_risk)';      % infected
Iidx2                       = (11:num_out:num_out*num_risk);
Isidx1                        = (6:num_out:num_out*num_risk)';      % newly infected
Isidx2                       = (14:num_out:num_out*num_risk)';

    for c=1 :num_cat
    x((c-1)*num_out*num_risk+Eidx1,:)   = repmat(range1(:,c),1,num_ens);
    x((c-1)*num_out*num_risk+Eidx2,:)   = repmat(range2(:,c),1,num_ens);
    x((c-1)*num_out*num_risk+Iidx1,:)  = max(x((c-1)*num_out*num_risk+Eidx1,:),0);
    x((c-1)*num_out*num_risk+Iidx2,:)  = max(x((c-1)*num_out*num_risk+Eidx2,:),0);
    x((c-1)*num_out*num_risk+Isidx1,:)  = max(x((c-1)*num_out*num_risk+Iidx1,:)/8,0);
    x((c-1)*num_out*num_risk+Isidx2,:)  = max(x((c-1)*num_out*num_risk+Iidx2,:)/8,0);
    x((c-1)*num_out*num_risk+Sidx1,:) = max(repmat(pop1(:,c),1,num_ens)-  x((c-1)*num_out*num_risk+Eidx1,:)- x((c-1)*num_out*num_risk+Iidx1,:)- x((c-1)*num_out*num_risk+Isidx1,:),0);
    x((c-1)*num_out*num_risk+Sidx2,:) = max(repmat(pop2(:,c),1,num_ens)-  x((c-1)*num_out*num_risk+Eidx2,:)- x((c-1)*num_out*num_risk+Iidx2,:)- x((c-1)*num_out*num_risk+Isidx2,:),0);
    end
    
% initialize the populations in all compartment sets (1 and 2) with pop0
pop1x               = repmat(pop1,1,1,num_ens);
pop1x               = permute(pop1x,[1 3 2]); % permute to get the right dimensions for three-dim operations
pop2x               = repmat(pop2,1,1,num_ens);
pop2x               = permute(pop2x,[1 3 2]); % permute to get the right dimensions for three-dim operations
pop                 = zeros(num_risk,num_ens,num_cat,2); 
pop(:,:,:,1)        = pop1x;
pop(:,:,:,2)        = pop2x;
