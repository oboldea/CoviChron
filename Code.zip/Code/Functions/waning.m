% function waning.m
% calculates the time-varying protection functions in the second set of
% compartments against infection (p_I), and hospitalization given
% infected (p_H)
% INPUTS 
% ve         : 2 x 3 vaccine effectiveness against I, HUNC, column is for Alpha/Delta/Waned
% ts         : scalar, time at which to evaluate
% bdate      : numerical date of code begin
% num_ens    : scalar no. of ensembles
% num_cat    : scalar no. of age categories
% vac        : 1 x num_risk x num_cat, number of fully
%              vaccinated per risk and age category at time ts
% pop0       : num_cat x num_risk, population by age and risk, constant

% OUTPUTS
% p1         : num_risk x num_ens x num_cat, protection against I 
% p2         : num_risk x num_ens x num_cat, conditional protection against H|I 

function [p1,p2,tg_wane_adults] = waning(ve,ts,bdate,num_ens,num_cat,vac,pop0)
% begin and end of each regime vaccine effectiveness
b_ve=ve(:,1);
e_ve=ve(:,2);
wane_ve=ve(:,3);
% input transition functions for Delta 
tg_delta=datenum('23-Jun-2021')-bdate+1;
gg_delta = exp(0.14*(ts-tg_delta));
gdelta = gg_delta/(1+gg_delta);
% input waning of vaccines adults, mid-point when 50% vaccines administered
%tg_wane_adults = datenum('12-Jul-2021')-bdate+1+90;
% calculate when vaccines hit 50% in each age category
tg_wane_adults = zeros(num_cat-2,1);
for c=3:num_cat
tgw=find(cumsum(sum(vac(:,:,c),2)/sum(pop0(c,:),2))>=0.5);
if isempty(tgw)==0
tg_wane_adults(c-2) = tgw(1);
end
end


gg_wane = exp(0.05*(ts-tg_wane_adults)); % waning in 6 months; 90 days is middle point
gwane_adults = gg_wane./(1+gg_wane); 


%calculate time-varying protection in the three regimes
vet1=zeros(num_cat-2,1);
vet2=zeros(num_cat-2,1);
for c=3:num_cat
    if tg_delta<tg_wane_adults(c-2)
        vet1(c-2,1) = b_ve(1,1)*(1-gdelta)+e_ve(1,1)*gdelta+ (wane_ve(1,1)-e_ve(1,1))*gwane_adults(c-2);
        vet2(c-2,1) = b_ve(2,1)*(1-gdelta)+e_ve(2,1)*gdelta+ (wane_ve(2,1)-e_ve(2,1))*gwane_adults(c-2);
    else
        vet1(c-2,1) = b_ve(1,1)*(1-gwane_adults(c-2))+ wane_ve(1,1)*gwane_adults(c-2);
        vet2(c-2,1) = b_ve(2,1)*(1-gwane_adults(c-2))+ wane_ve(2,1)*gwane_adults(c-2);
    end
end
ve1_adults=vet1;  % p_I
ve2_adults= min(max((vet2-ve1_adults)./(1-ve1_adults),0),1); % p_H protection against hospitalization conditional of infection

% distribute across 11 age groups
p1 = repmat([repmat(ve1_adults(1,1),2,1);ve1_adults],1,num_ens); % children like adolescents 10-20
p2 = [repmat(ve2_adults(1,1),2,1);ve2_adults];

