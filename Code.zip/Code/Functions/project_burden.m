% function project_burden
% outputs new weekly infections and new hospitalizations depending on vaccine effectiveness and initially vaccinated fractions of
% population

% INPUTS
% contacts          : num_cat x num_risk x num_cat x num_risk contacts
% pop0              : num_cat x num_risk, population by age and risk, constant
% num_ens           : number of ensemble draws 
% num_out           : scalar, number of state variable per age x risk that
%                     are updated
% num_risk          : scalar, no. of risk categories
% num_cat           : scalar no. of age categories
% VX                : 1 x num_risk x num_cat, number of vaccines
%                       administered progressively, set to zero as vaccination occurs before the
%                       projections start
% delta             : num_cat x1 hospital discharge rates 
% para              : num_para x num_ens parameter posteriors 
% num_times         : number of weeks to project forward
% p1_inf            : num_cat x num_risk protection against infection in
%                     with no recent vaccination
% p1_hos            : num_cat x num_risk protection against hospitalization
%                     given infection with no recent vaccination
% p2_inf            : num_cat x num_risk protection against infection in
%                     with recent vaccination
% p2_hos            : num_cat x num_risk protection against hospitalization
%                     given infection with recent vaccination
% v_frac            : num_cat x num_risk vaccination coverage by age and
%                     risk administered before projection 
% OUTPUTS
% hos               : num_cat x num_ens x num_risk x num_times x 2 new
%                     weekly new hospitalization by age, risk and for no recent vaccination and
%                     recent vaccination (compartment sets 1 and 2)
% inf               : num_cat x num_ens x num_risk x num_times x 2 new
%                     weekly new infections by age, risk and for no recent vaccination and
%                     recent vaccination (compartment sets 1 and 2) 

function [hos,inf] = project_burden(contacts,pop0,num_ens,num_out,num_risk,num_cat,VX,delta,para,num_times,p1_inf,p1_hos,p2_inf,p2_hos,v_frac)
  
%draw prior
[x,pop]=initialize_proj(pop0,num_ens,num_out,v_frac,para);
num_para =size(para,1);
num_var=size(x,1);                   % number of state variables including parameters
num_s = num_var-num_para;            % number of state variables without parameters


num_vax=2;
% initialize projections for all state variables and population
x_post=zeros(num_var,num_ens,num_times);                            % all states
pop_post=zeros(num_risk,num_ens,num_cat,2,num_times);               % population in the two compartment sets

hos = zeros(num_cat,num_ens,(num_risk+1),num_times,num_vax);       % memorize weekly new hospitalization posteriors 1
inf = zeros(num_cat,num_ens,(num_risk+1),num_times,num_vax);       % memorize weekly new infections in all age x risk categories modelled

for t=1:num_times
    %t  % display week
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % RUN SEIRHS
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
      x_temp = zeros(num_var,num_ens);
    for j=1:7 % run for a week to get weekly data
        x(num_s+1:end,:) = para;
        [x,pop]=SEIRHS_proj(x,pop,7*(t-1)+j,contacts,num_out,delta,VX,num_ens,pop0,p1_inf,p1_hos,p2_inf,p2_hos);
        [x, pop] = remainder(x,pop,num_risk,num_cat,num_out,num_ens); 
        x_temp = x_temp+x; % add to extract new weekly instead of new daily hospitalizations
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for c=1:num_cat
        for i=1:num_risk
              hos(c,:,i,t,1) = x_temp((c-1)*num_out*num_risk+(i-1)*num_out+7,:);
              hos(c,:,i,t,2) = x_temp((c-1)*num_out*num_risk+(i-1)*num_out+15,:);
               inf(c,:,i,t,1) = x_temp((c-1)*num_out*num_risk+(i-1)*num_out+6,:);
               inf(c,:,i,t,2) = x_temp((c-1)*num_out*num_risk+(i-1)*num_out+14,:);
         end
        hos(c,:,end,t,:) = sum(hos(c,:,:,t,:),3);
        inf(c,:,end,t,:) = sum(inf(c,:,:,t,:),3);
    end
         
 
       x = checkbound_proj(x,pop,num_cat,num_out);
       [hos,inf]= checkbound_week(hos,inf);
  
   % memorize model updates at each time point
  x_post(:,:,t)=x;
  pop_post(:,:,:,:,t)=pop; % memorize movement of population from compartment set 1 to compartment set 2

end
    