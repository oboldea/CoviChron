% function that initializes the metapopulation SEIRHS model
% INPUTS
% pop0          : num_cat x num_risk matrix of population in age-risk group
% num_ens       : number of initial ensemble draws
% num_out   	: number of compartments (state variable) for a given risk
%                  group and age category
% parabounds    : num_para x 2 parameter prior bounds
% OUTPUTS
% x             : (num_var+num_para) x num_ens matrix, all initializations
%                 for variables and parameters
% pop           : num_risk x num_ens x num_cat x 2 array. The forth dimension refers to compartment sets


function [x,pop]=initialize(pop0,num_ens,num_out,parabounds)

% retrieve relevant dimensions of data
[num_cat, num_risk]          = size(pop0);
num_para                    = size(parabounds,1);
% initialize variables and parameters
x                           = zeros(num_out*num_risk*num_cat+num_para,num_ens);

% Latin Hypercube sampling of all parameters 
xmin                       = parabounds(:,1);
xmax                       = parabounds(:,2);
x(end-num_para+1:end,:)    = lhsu(xmin,xmax,num_ens,num_para);


% calculate the fraction of population in each risk-age group
N                           = sum(sum(pop0,1),2);
frac_pop                    = (pop0/N)'; 
pop0                        = pop0';

% distribute at population shares the initial range draws
Sidx                        = (1:num_out:num_out*num_risk)';      % susceptibles
Eidx                        = (2:num_out:num_out*num_risk)';      % exposed
Iidx                       = (3:num_out:num_out*num_risk)';      % infected
Isidx                       = (6:num_out:num_out*num_risk)';      % newly infected

    for c=1 :num_cat
    x((c-1)*num_out*num_risk+Eidx,:)   = max(round((frac_pop(:,c))*x(end-num_para+1,:)/2),0);
    x((c-1)*num_out*num_risk+Iidx,:)  = max(x((c-1)*num_out*num_risk+Eidx,:),0);
    x((c-1)*num_out*num_risk+Isidx,:)  = max(x((c-1)*num_out*num_risk+Iidx,:)/8,0); % doubles every day
    x((c-1)*num_out*num_risk+Sidx,:)   = pop0(:,c)*ones(1,num_ens)- x((c-1)*num_out*num_risk+Eidx,:)-x((c-1)*num_out*num_risk+Iidx,:)-x((c-1)*num_out*num_risk+Isidx,:);
    end
    
% initialize the populations in all compartment sets (1 and 2) with pop0
pop0x               = repmat(pop0,1,1,num_ens);
pop0x               = permute(pop0x,[1 3 2]); % permute to get the right dimensions for three-dim operations
pop                 = zeros(num_risk,num_ens,num_cat,2);%initialize vaccinated pop0ulation to zero
pop(:,:,:,1)        = pop0x;



    function s=lhsu(xmin,xmax,nsample,num_para)
        % function drawing Latin Hypercube draw from all parameters
    ran=rand(nsample,num_para);
    s=zeros(num_para,nsample);
    for j=1: num_para
        idx=randperm(nsample);
        P =(idx'-ran(:,j))/nsample;
        s(j,:) = xmin(j) + P.* (xmax(j)-xmin(j));
    end

