close all
addpath(genpath(pwd))
data1=readtable('dates.xlsx','ReadVariableNames',1); % import dates
date1 = datetime(data1.week, 'InputFormat', 'MM-dd-yyyy');
dates_plot=date1(1:8:end,:);
load Data/pop                % load population 
pop0=pop;
load Data/hos1                % load weekly new hospitalizations, Dataset 1: by age, all risk, age categories: 0-10,10-20,,...,80-90,90+ 
load Data/hos2                % load weekly new hospitalizations, Dataset 2: medium plus high 
load Data/vac                 % load weekly vaccinations, data starts on Jan 18, 2021
load Data/sero1               % load sero data, 6 rounds
load Data/sero2
load Data/sero3
load Data/sero4
load Data/sero5
load Data/sero6 
hos1 = hos1(2:end,:);
hos2 = hos2(2:end,:);

load Output/hos_fit
load Output/hos_fit_sum
load Output/hos_fit_low
load Output/hos2_fit
load Output/hos2_fit_sum
load Output/sero_fit
load Output/sero_fit_sum
load Output/sero_fit2
load Output/sero_fit_sum2
% initializations
num_arisk =4;
num_cat =11;
num_risk=3;
num_ens=300;
num_times =96;
survey1=[1;3];                                                % identify index of surveys where data is for all risk categories
survey2=[2;4;5;6];                                           % identify index of surveys where data is for high/medium and low risk categories
tsero = [3;14;29;50;68;88];
ix_sero1 = 1:1:5;
ix_sero2 = [6,8,10,12,14]; % low risk sero data index
ix_sero3 = [7,9,11,13,15]; % high risk sero data index
% define sero data points, surveys 1-3 by age
sero_data.mean = NaN(num_cat-1,num_times);
for t=1:num_times
    for se=1:length(survey1)
        if se==1
            data_se = sero1;
        else
            data_se = sero3;
        end
        if t==tsero(survey1(se))
        sero_data.mean(:,t) = data_se.mean/100;
        end
    end
        
    for se=1:length(survey2)
              if se==1
                  data_se = sero2; 
              elseif se==2
                  data_se = sero4;
              elseif se==3
                  data_se = sero5;
              elseif se==4
                  data_se = sero6;
              end
              for c=1:5
        if t==tsero(survey2(se))
        sero_data.mean(1:5,t) = data_se.mean(1:5)/100;
        end
              end

    end
end
% define sero data surveys 2,4,5,6 by age and risk - ages 40-50, 50-60, ...80+
sero_data.mean2 = NaN(5,num_times,2);
for t=1:num_times
     for se=1:length(survey2)
              if se==1
                  data_se = sero2; 
              elseif se==2
                  data_se = sero4;
              elseif se==3
                  data_se = sero5;
              elseif se==4
                  data_se = sero6;
              end
             for c=1:5
            if t==tsero(survey2(se))
            sero_data.mean2(:,t,1) = data_se.mean(ix_sero2)/100;
            sero_data.mean2(:,t,2) = data_se.mean(ix_sero3)/100;
            end
            end

    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 1: plot fit to hospitalization data hos1
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xtitle = ["[0-10)";"[10,20)";"[20,30)";"[30,40)";"[40-50)";"[50,60)";"[60,70)";"[70,80)";"[80,90)";"90+"];
gr=[0.85,0.85,0.85];
col1=rgb('RoyalBlue');
col2=rgb('DarkMagenta');
col3=rgb('Green');
col4 = rgb("DeepSkyBlue");
col5=rgb("Orchid");
figure(1)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
for c=1:num_cat-1
subplot(5,2,c)
hold on
box on
ax = gca;
ax.LineWidth = 2;
   post = squeeze(hos_fit(c,:,:));
   mean1=mean(post,1);
    ci= quantile(post, [.025 .975]);
     ci(1,:)=ci(1,:);
     ci(2,:)=ci(2,:);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))];
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',10);
   post2 = squeeze(hos_fit_sum(c,:,:));
   mean2=mean(post2,1);
    ci= quantile(post2, [.025 .975]);
     ci(1,:)=ci(1,:);
     ci(2,:)=ci(2,:);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))];
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',10);
  
   plot(date1,mean2(1,:),'LineWidth',3,'color', col3); % plot mean fit from sum of unobservered updates
  plot(date1,mean1(1,:),'LineWidth',2,'color', col1); % plot mean fit from observed updates
  plot(date1,hos1(:,c),'.','MarkerSize',10,'color', col2); 
  title(xtitle(c));
  set(gca,'fontsize',20);
end
lgd=legend({' 95% CrI sum of unobserved updates','','Mean sum of unobserved updates','Mean of observed update','Data'},'Location','bestoutside');
set(lgd,...
    'Position',[0.00851677084415827 0.894951745912191 0.176100624280062 0.0961395666700162]);

%sgtitle('Weekly hospitalizations for all risk groups combined','FontSize',30)
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 1: plot fit to hospitalization data hos2
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

xtitle = ["[0-40) High";"[0-40) Low";"[40,60) High";"[40,60) Low";"[60,80) High";"[60,80) Low"; "80+ High"; "80+ Low"];
% calculate population by risk
pop_new = zeros(num_arisk,2);
pop_new(1,1) = sum(pop0(1:5,1:2),"all");
pop_new(1,2) = sum(pop0(1:5,3),"all");
pop_new(2,1) = sum(pop0(6:7,1:2),"all");
pop_new(2,2) = sum(pop0(6:7,3),"all");
pop_new(3,1) = sum(pop0(8:9,1:2),"all");
pop_new(3,2) = sum(pop0(8:9,3),"all");
pop_new(4,1) = sum(pop0(10:11,1:2),"all");
pop_new(4,2) = sum(pop0(10:11,3),"all");
pop_new=pop_new/1000;
% calculate hos2 data for low risk
hos3= zeros(num_times,num_arisk);
for c=1:num_arisk
if c==1
hos3(:,1) = (sum(hos1(:,1:4),2)-hos2(:,c))/pop_new(c,2);
elseif c==2
hos3(:,2) = (sum(hos1(:,5:6),2)-hos2(:,c))/pop_new(c,2);
elseif c==3
hos3(:,3) = (sum(hos1(:,7:8),2)-hos2(:,c))/pop_new(c,2);
else 
hos3(:,4) = (sum(hos1(:,9:10),2)-hos2(:,c))/pop_new(c,2);
end
end
figure(2)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
for c=1:num_arisk
subplot(4,2,2*(c-1)+1)
hold on
box on
ax = gca;
ax.LineWidth = 2;
   post = squeeze(hos2_fit(c,:,:));
   mean1=mean(post,1);
     post2 = squeeze(hos2_fit_sum(c,:,:));
   mean2=mean(post2,1);
    ci= quantile(post2, [.025 .975]);
     ci(1,:)=ci(1,:);
     ci(2,:)=ci(2,:);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))]/pop_new(c,1);
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',3);
 % observed updates only occur when data available
  for t=1:num_times
     if isnan(hos2(t,c))==1 % check if missing data
     mean1(1,t) =NaN;
     end
  end
  plot(date1,mean2(1,:)/pop_new(c,1),'LineWidth',3,'color', col3); % plot mean fit from sum of unobservered updates
  plot(date1,mean1(1,:)/pop_new(c,1),'LineWidth',3,'color', col1); % plot mean fit from observed updates
  plot(date1,hos2(:,c)/pop_new(c,1),'.','MarkerSize',10,'color', col2); 
    ylim([0 max(hos2_fit(c,:,:)/pop_new(c,1),[],"all")]);
    title(xtitle(2*c-1));
    set(gca,'fontsize',15);

%sgtitle('1,000 hospitalized by risk groups, as a fraction of their population','FontSize',30)
if c==1
lgd=legend({' 95% CrI sum of unobserved updates','Mean sum of unobserved updates','Mean of observed update','Data'});
set(lgd,...
    'Position',[0.0098618474803119 0.887344349247742 0.17773437029682 0.103930458099844],...
    'FontSize',20);
end
subplot(4,2,2*c)
hold on
box on
ax = gca;
ax.LineWidth = 2;
   post2 = squeeze(hos_fit_low(c,:,:));
   mean2=mean(post2,1);
    ci= quantile(post2, [.025 .975]);
     ci(1,:)=ci(1,:);
     ci(2,:)=ci(2,:);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))]/pop_new(c,2);
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',3);
  plot(date1,mean2(1,:)/pop_new(c,2),'LineWidth',3,'color', col3); % plot mean fit from sum of unobservered updates
  plot(date1,hos3(:,c),'.','MarkerSize',10,'color', col2); 
  ylim([0 max(hos2_fit(c,:,:)/pop_new(c,1),[],"all")]);
    title(xtitle(2*c));
    set(gca,'fontsize',15);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3: plot fit to sero surveys 1 and 3
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xtitle = ["[0-5)";"[5,10)";"[10,20)";"[20,30)";"[30,40)";"[40-50)";"[50,60)";"[60,70)";"[70,80)";"80+"];
figure(3)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
for c=1:num_cat-1
subplot(5,2,c)
hold on
box on
ax = gca;
ax.LineWidth = 2;
    post2 = squeeze(sero_fit_sum(c,:,:));
   mean2=mean(post2,1);
    ci= quantile(post2, [.025 .975]);
     ci(1,:)=ci(1,:);
     ci(2,:)=ci(2,:);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))];
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',10);
   post = squeeze(sero_fit(c,:,:));
   mean1=mean(post,1);
   ci=zeros(2,num_times);
   ci(:,tsero(1)) = quantile(post(:,tsero(1)), [.025 .975]);
   ci(:,tsero(3)) = quantile(post(:,tsero(3)), [.025 .975]);
   xx = date1(tsero(1));
   yy= (ci(:,tsero(1)))';
  
  
  plot(date1,mean2(1,:),'LineWidth',3,'color', col3); % plot mean fit from sum of unobservered updates
  plot(date1,mean1(1,:),'.','MarkerSize',30,'color', col1); % plot mean fit from observed updates
  plot(date1,sero_data.mean(c,:),'.','MarkerSize',30,'color', col2); 
  
    title(xtitle(c));
    set(gca,'fontsize',15);
end
lgd=legend({' 95% CrI unobserved updates','Mean sum of unobserved updates','Mean of observed update','Data'},'Location','bestoutside');
set(lgd,...
    'Position',[0.00340670795107663 0.886043061569344 0.178852196525103 0.102078690472229],...
    'FontSize',20);
%sgtitle('Weekly seroprevalence for all risk groups combined','FontSize',30)
hold off;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4: plot fit to sero surveys 2,4,5,6
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xtitle = ["[40-50) Low ";"[40-50) High"; "[50,60) Low";"[50,60) High";"[60,70) Low";"[60,70) High"; "[70,80) Low";"[70,80) High";...
    "80+ Low";"80+ High"];

figure(4)
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
for i=1:num_cat-1
subplot(5,2,i)
hold on
box on
ax = gca;
ax.LineWidth = 2;
if mod(i,2)==1
    post2 = squeeze(sero_fit_sum2(5+round(i/2),:,:,1));
    post = squeeze(sero_fit2(5+round(i/2),:,:,1));
else
    post2 = squeeze(sero_fit_sum2(5+round(i/2),:,:,2));
    post = squeeze(sero_fit2(5+round(i/2),:,:,2));
end
   mean1=mean(post,1);
   mean2=mean(post2,1);
    ci= quantile(post2, [.025 .975]);
     xx=[date1' fliplr(date1')];
         yy=[ci(1,:) fliplr(ci(2,:))];
    hold on
   patch(xx,yy,gr,'EdgeColor',gr,'Linewidth',10);
  plot(date1,mean2(1,:),'LineWidth',3,'color', col3); % plot mean fit from sum of unobservered updates
  plot(date1,mean1(1,:),'.','MarkerSize',30,'color', col1); % plot mean fit from observed updates
  if mod(i,2)==1
  plot(date1,sero_data.mean2(round(i/2),:,1),'.','MarkerSize',30,'color', col2); 
  else
   plot(date1,sero_data.mean2(round(i/2),:,2),'.','MarkerSize',30,'color', col2); 
  end
  
    title(xtitle(i));
    set(gca,'fontsize',20);
end
lgd=legend({' 95% CrI unobserved updates','Mean sum of unobserved updates','Mean of observed update','Data'},'Location','bestoutside');
set(lgd,...
    'Position',[0.00733752556113952 0.888270233061549 0.178852196525103 0.10207869047223],...
    'FontSize',15);
%sgtitle('Weekly seroprevalence by risk groups','FontSize',30)
hold off;
