addpath(genpath(pwd))
close all
clear
clc;
tic
rng(2);                      % set seed 
%%%%%%%%%%%%%%%%%Projections for the SEIRHS model%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LOAD DATA AND PARAMETER ESTIMATES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load Output/x_e              % load parameter estimates

load Data/pop                % load population 
load Data/cont;              % load contact survery rounds

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SELECT SUBSAMPLE TO RUN THE MODEL PLUS INITIALIZATIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% initializations
num_risk=3;                     % number of risk groups, high first, then medium, then low
num_times= 24;                  % time series sample size
num_cat=11;                     % number of age categories
num_out= 18;                    % number of state outputs of SEIRHS function for each risk-age group     
num_ens=300;                    % number of ensemble members for EAKF
num_scen = 10;                  % number of scenarios
num_vax  = 2;                   % compartment sets
num_para = 22;
para = x_e(end-num_para+1:end,:,end);

para(end,:) = zeros(1,num_ens); % remove waning
% calculate contacts
contacts= squeeze(cont(end-1,:,:,:,:));
pop0=pop;                       % rename pop to initial population, as pop will be used later to track pop in first and second compartment sets  


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CALIBRATIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

range   = 1000;                          % prior range 
para(end-num_para+1,:)                   =range(1,1)*ones(1,num_ens);
deltac=[1/8;1/3;1/3];                    % median time release from hospital, calibrated

% replicate delta to be num_risk x num_ens x num_cat x num_vax (num_vax is 2,
% number of compartment sets)
delta            = repmat([ones(2,1)*deltac(2);deltac(3);ones(8,1)*deltac(1)],1,num_ens);
% replicate it to be the same for risk groups (format:
% num_risk x num_ens x num_cat)
delta  = repmat(permute(delta,[3 2 1]),num_risk,1,1,2);
VX = zeros(1,num_risk,num_cat); % vaccinated before any wave, set progressive vaccinations to zero
% initialize vaccine effectiveness in the two compartment sets

p1_inf = 0.36*ones(num_cat,num_risk); 
p2 =[0.37*ones(7,num_risk);0.51*ones(4,num_risk)];
p2_inf = 1-(1-p2).*(1-p1_inf);

p1_unc_hos = 0.83*ones(num_cat, num_risk);
p1_hos = min(max((p1_unc_hos-p1_inf)./(1-p1_inf),0),1); 
%p1_hos = 0.9*ones(num_cat, num_risk);
% calcutate age-specific unconditional protection relative to no previous
% infection in a year
p2 = [0.63*ones(7,num_risk);ones(2,1)*[0.73 0.67 0.67]; ones(2,1)*[0.64 0.64 0.69]];
p2_unc_hos = 1-(1-p2).*(1-p1_unc_hos);
p2_hos = min(max((p2_unc_hos-p2_inf)./(1-p2_inf),0),1); 
% approximate percentage vaccination in each age group

v_real = [   0         0         0;
         0         0         0;
         0         0         0;
    0.1000    0.0500    0.0200;
    0.1000    0.0500    0.0200;
    0.1000    0.0500    0.0200;
    0.2000    0.1200    0.0800;
    0.5000    0.5000    0.4000;
    0.6500    0.6500    0.6500;
    0.7000    0.6400    0.6400;
    0.5600    0.5600    0.5600];


% initialize summary data
hos = zeros(num_cat,num_ens,(num_risk+1),num_times,num_vax,num_scen);
inf = zeros(num_cat,num_ens,num_risk+1,num_times,num_vax,num_scen);
peak_hos = zeros(num_cat,num_ens,num_risk+1,num_vax,num_scen);


%percentage of population vaccinated
scenario=1:1:num_scen;
v_frac =zeros(num_cat,num_risk,num_scen);
for i=1:num_scen
   if i==1
       v_frac(:,:,i) =zeros(num_cat,num_risk); % no one vaccinated
   elseif i==2
       v_frac(:,:,i) =0.5*ones(num_cat,num_risk); 
    elseif i==3
       v_frac(:,1,i) = 0.5*ones(num_cat,1); % H risk
   elseif i==4
       v_frac(:,1,i) = 0.75*ones(num_cat,1); % H risk
   elseif i==5
       v_frac(:,1:2,i) = 0.5*ones(num_cat,2); % H/M risk
   elseif i==6
         v_frac(:,1,i) = 0.75*ones(num_cat,1); % H risk
          v_frac(:,2,i) = 0.5*ones(num_cat,1); % M risk
   elseif i==7
        v_frac(:,1:2,i) = 0.75*ones(num_cat,2); % H/M risk
    elseif i==8
         v_frac(:,1:2,i) = 0.75*ones(num_cat,2); % H/M risk
         v_frac(:,3,i) = 0.25*ones(num_cat,1);  % L risk
   elseif i==9
     v_frac(:,1:2,i) = 0.75*ones(num_cat,2); % H/M risk
         v_frac(:,3,i) = 0.5*ones(num_cat,1); % L risk
          elseif i==10
     v_frac(:,:,i) = 0.75*ones(num_cat,num_risk); % H/M/L risk
   end
end
for i=1:num_scen
    scenario=i
[hos_temp,inf_temp]= project_burden(contacts,pop0,num_ens,num_out,num_risk,num_cat,VX,delta,para,num_times,p1_inf,p1_hos,p2_inf,p2_hos,v_frac(:,:,i));
 hos(:,:,:,:,:,i) = hos_temp;
 inf(:,:,:,:,:,i) = inf_temp;
end
toc
tables_pictures_vax_percentage_risk(inf,hos,num_scen,num_times,v_frac,num_ens);

