% plots parameter posteriors
addpath(genpath(pwd))
close all
load Output/x_e
load Output/parabounds
data1=readtable('dates.xlsx','ReadVariableNames',1); % import dates
date1 = datetime(data1.week, 'InputFormat', 'MM-dd-yyyy');
dates_plot=date1(1:8:end,:);
num_para = 22;
para=x_e(end-num_para+1:end,:,:);
nbins=50;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 1 : susceptibility estimates
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% index of parameters to be plotted
ix_para1=(2:1:4)';
figure(1)
names_para1 = ["f [0,20)", "f [20,60]", "\epsilon 60+"];
para1 = para(ix_para1,:,:);
parabounds1 = parabounds(ix_para1,:);
tiledlayout(2,2);
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
n1=size(para1,1);
for s=1:n1
    nexttile
    post=squeeze(para1(s,:,end));
  histogram(post,nbins,'FaceColor',rgb('CornFlowerBlue'),'EdgeColor',rgb('CornFlowerBlue')); hold on
        xline(mean(post),'r', 'LineWidth',3);
    title(names_para1(s),'fontsize',40);
    set(gca,'Fontsize',20)
    if parabounds1(s,1)~=parabounds1(s,2)
    xlim(parabounds1(s,:));
    end
    set(gca,'Box','on','Layer', 'Top');  
    set(gca,'YTickLabel',[]);


end
%sgtitle('Susceptibility estimates over prior range ','Fontsize',20);
lgd=legend({'Distribution end of sample','Mean'},'Location','northwest');
set(lgd,...
    'Position',[0.34001572327044 0.400757858337845 0.128515621763654 0.0502645488679184]);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gammalowidx     =(5:15)'; % gamma low risk up to age 90+ (first 11 elements of gamma)
ix_para1 = reshape(gammalowidx,[],1);
names_para1 = ["f [0-5)"; "f [5,10)";"f [10,20)";"f [20,30)";"f [30,40)";"f [40-50)";"f [50,60)";"f [60,70)";"f [70,80)";"f [80,90)";"\gamma 90+"];
para1 = para(ix_para1,:,:);
parabounds1 = parabounds(ix_para1,:);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 2 : hospitalization rates in low risk groups
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2)
tiledlayout(4,3);
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);
n1=size(para1,1);
rel_post = squeeze(para1(n1,:,end));
for s=1:n1
    nexttile
    if s~=n1
    post=squeeze(para1(s,:,end))./rel_post;
    else 
        post= squeeze(para1(s,:,end));
    end
   histogram(post,nbins,'FaceColor',rgb('CornFlowerBlue'),'EdgeColor',rgb('CornFlowerBlue')); hold on
    xline(mean(post),'r', 'LineWidth',3)
    title(names_para1(s),'fontsize',40);
    set(gca,'Fontsize',20)
    set(gca,'YTickLabel',[]);
    if parabounds1(s,1)~=parabounds1(s,2)
            if s<=10
        xlim([0.5*min(post) 1.5*max(post)])
            elseif s~=n1
        xlim(sort(parabounds1(s,:)./parabounds1(n1,:)));
            else
         xlim(parabounds1(s,:));   
            end
    end
    set(gca,'Box','on','Layer', 'Top');  
    set(gca,'YTickLabel',[]);
 %  sgtitle('Hospitalization rates in low risk groups over prior range - end of sample','Fontsize',20);
end
lgd=legend({'Distribution','Mean'},'Location','northwest');
set(lgd,...
    'Position',[0.551712089447938 0.193264354962696 0.0671874985913746 0.0502645488679184]);

 % high and medium risk groups
 % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gammahighidx     =(16:19)'; % high risk
ix_para1 = reshape(gammahighidx,[],1);
names_para1 = ["f [0,40)";"f [40-60)";"f [60,80)";"f 80+"];
para1 = para(ix_para1,:,:);
parabounds1 = parabounds(ix_para1,:);
n1=size(para1,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3 : hospitalization rates in high/medium risk groups
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(3)
tiledlayout(2,2);
set(gcf, 'Units', 'Normalized', 'OuterPosition', [0 0 1 1]);

for s=1:n1
    nexttile
    
    post=squeeze(para1(s,:,end));
   
    histogram(post,nbins,'FaceColor',rgb('CornFlowerBlue'),'EdgeColor',rgb('CornFlowerBlue')); hold on
    xline(mean(post),'r', 'LineWidth',3)
    title(names_para1(s),'fontsize',40);
    set(gca,'Fontsize',20)
    set(gca,'YTickLabel',[]);
    if parabounds1(s,1)~=parabounds1(s,2)
        
         xlim(parabounds1(s,:));   
     end
    set(gca,'Box','on','Layer', 'Top');  
    set(gca,'YTickLabel',[]);    
    %sgtitle('Hospitalization rates in high/medium risk groups relative to low risk groups - end of sample','Fontsize',20);

end
legend({'Distribution','Mean'},'Location','northwest');


